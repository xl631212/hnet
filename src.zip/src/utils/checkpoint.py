import torch
import os
from pathlib import Path
from typing import Dict, Optional
import logging


def save_checkpoint(state: Dict, filepath: str):
    """保存检查点
    
    Args:
        state: 包含模型状态、优化器状态等的字典
        filepath: 保存路径
    """
    filepath = Path(filepath)
    filepath.parent.mkdir(parents=True, exist_ok=True)
    
    try:
        torch.save(state, filepath)
        logging.info(f"检查点已保存到: {filepath}")
    except Exception as e:
        logging.error(f"保存检查点失败: {e}")
        raise


def load_checkpoint(filepath: str, device: torch.device) -> Dict:
    """加载检查点
    
    Args:
        filepath: 检查点文件路径
        device: 目标设备
        
    Returns:
        检查点字典
    """
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"检查点文件不存在: {filepath}")
        
    try:
        checkpoint = torch.load(filepath, map_location=device)
        logging.info(f"检查点已从 {filepath} 加载")
        return checkpoint
    except Exception as e:
        logging.error(f"加载检查点失败: {e}")
        raise


def get_latest_checkpoint(checkpoint_dir: str) -> Optional[str]:
    """获取最新的检查点文件
    
    Args:
        checkpoint_dir: 检查点目录
        
    Returns:
        最新检查点的路径，如果没有找到则返回None
    """
    checkpoint_dir = Path(checkpoint_dir)
    
    if not checkpoint_dir.exists():
        return None
        
    # 查找所有检查点文件
    checkpoint_files = list(checkpoint_dir.glob('checkpoint_*.pth'))
    
    if not checkpoint_files:
        return None
        
    # 按修改时间排序，返回最新的
    latest_checkpoint = max(checkpoint_files, key=lambda x: x.stat().st_mtime)
    return str(latest_checkpoint)


def cleanup_old_checkpoints(checkpoint_dir: str, keep_last_n: int = 5):
    """清理旧的检查点文件，只保留最新的N个
    
    Args:
        checkpoint_dir: 检查点目录
        keep_last_n: 保留的检查点数量
    """
    checkpoint_dir = Path(checkpoint_dir)
    
    if not checkpoint_dir.exists():
        return
        
    # 查找所有epoch检查点文件（不包括best和latest）
    checkpoint_files = list(checkpoint_dir.glob('checkpoint_epoch_*.pth'))
    
    if len(checkpoint_files) <= keep_last_n:
        return
        
    # 按修改时间排序
    checkpoint_files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
    
    # 删除旧的检查点
    for checkpoint_file in checkpoint_files[keep_last_n:]:
        try:
            checkpoint_file.unlink()
            logging.info(f"删除旧检查点: {checkpoint_file}")
        except Exception as e:
            logging.warning(f"删除检查点失败 {checkpoint_file}: {e}")


def resume_from_checkpoint(model, optimizer, scheduler, scaler, checkpoint_path: str, device: torch.device):
    """从检查点恢复训练状态
    
    Args:
        model: 模型
        optimizer: 优化器
        scheduler: 学习率调度器
        scaler: 混合精度缩放器
        checkpoint_path: 检查点路径
        device: 设备
        
    Returns:
        (epoch, global_step, best_metric)
    """
    checkpoint = load_checkpoint(checkpoint_path, device)
    
    # 加载模型状态
    model.load_state_dict(checkpoint['model_state_dict'])
    
    # 加载优化器状态
    if optimizer is not None and 'optimizer_state_dict' in checkpoint:
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        
    # 加载调度器状态
    if scheduler is not None and 'scheduler_state_dict' in checkpoint:
        scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        
    # 加载缩放器状态
    if scaler is not None and 'scaler_state_dict' in checkpoint:
        scaler.load_state_dict(checkpoint['scaler_state_dict'])
        
    epoch = checkpoint.get('epoch', 0)
    global_step = checkpoint.get('global_step', 0)
    best_metric = checkpoint.get('best_metric', 0.0)
    
    return epoch, global_step, best_metric