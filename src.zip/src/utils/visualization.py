import matplotlib.pyplot as plt
import matplotlib.patches as patches
from PIL import Image
from typing import Dict, List

def visualize_scene_graph(image_path: str, pred_scene_graph: Dict, true_scene_graph: Dict, 
                          object_classes: List[str], predicate_classes: List[str], attribute_classes: List[str],
                          output_path: str):
    """可视化预测和真实的场景图"""
    
    img = Image.open(image_path).convert('RGB')
    fig, ax = plt.subplots(1, 2, figsize=(20, 10))
    
    # 可视化预测
    ax[0].imshow(img)
    ax[0].set_title('Predicted Scene Graph')
    ax[0].axis('off')
    draw_scene_graph(ax[0], pred_scene_graph, object_classes, predicate_classes, attribute_classes)
    
    # 可视化真实
    ax[1].imshow(img)
    ax[1].set_title('Ground Truth Scene Graph')
    ax[1].axis('off')
    draw_scene_graph(ax[1], true_scene_graph, object_classes, predicate_classes, attribute_classes, is_gt=True)
    
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()

def draw_scene_graph(ax, scene_graph: Dict, object_classes: List[str], predicate_classes: List[str], 
                     attribute_classes: List[str], is_gt: bool = False):
    """在图像上绘制场景图"""
    
    if is_gt:
        boxes = scene_graph['object_boxes']
        labels = scene_graph['object_labels']
        attrs = scene_graph.get('attribute_labels')
        rels = scene_graph.get('relationship_triplets')
    else:
        # 从预测中获取数据
        pred_boxes = scene_graph['boundary_predictions']
        pred_obj_logits = scene_graph['object_logits']
        pred_attr_logits = scene_graph['attribute_logits']
        pred_rel_logits = scene_graph['relationship_logits']
        
        # 简单的后处理：取argmax
        boxes = pred_boxes.cpu().numpy()
        labels = pred_obj_logits.argmax(-1).cpu().numpy()
        if pred_attr_logits is not None:
            attrs = pred_attr_logits.argmax(-1).cpu().numpy()
        else:
            attrs = None
        # 关系需要更复杂的处理，这里简化
        rels = []

    # 绘制包围框和标签
    for i in range(len(boxes)):
        box = boxes[i]
        label_idx = labels[i]
        label_name = object_classes[label_idx]
        
        rect = patches.Rectangle((box[0], box[1]), box[2] - box[0], box[3] - box[1], 
                                 linewidth=1, edgecolor='r', facecolor='none')
        ax.add_patch(rect)
        
        text = f'{label_name}'
        if attrs is not None and i < len(attrs):
            attr_idx = attrs[i]
            attr_name = attribute_classes[attr_idx]
            text += f'\n({attr_name})'
            
        ax.text(box[0], box[1], text, fontsize=8, color='white', backgroundcolor='red')

    # 绘制关系 (简化版)
    if rels is not None:
        for rel in rels:
            sub_idx, obj_idx, pred_idx = rel
            sub_box = boxes[sub_idx]
            obj_box = boxes[obj_idx]
            pred_name = predicate_classes[pred_idx]
            
            sub_center = (sub_box[0] + sub_box[2] / 2, sub_box[1] + sub_box[3] / 2)
            obj_center = (obj_box[0] + obj_box[2] / 2, obj_box[1] + obj_box[3] / 2)
            
            ax.plot([sub_center[0], obj_center[0]], [sub_center[1], obj_center[1]], 'g-')
            mid_point = ((sub_center[0] + obj_center[0]) / 2, (sub_center[1] + obj_center[1]) / 2)
            ax.text(mid_point[0], mid_point[1], pred_name, fontsize=8, color='white', backgroundcolor='green')