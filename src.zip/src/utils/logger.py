import logging
import os
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional


def setup_logger(name: str, log_dir: str, level: int = logging.INFO) -> logging.Logger:
    """设置日志记录器
    
    Args:
        name: 日志记录器名称
        log_dir: 日志文件目录
        level: 日志级别
        
    Returns:
        配置好的日志记录器
    """
    # 创建日志目录
    log_dir = Path(log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    
    # 创建日志记录器
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # 避免重复添加处理器
    if logger.handlers:
        return logger
    
    # 创建格式器
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # 控制台处理器
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # 文件处理器
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = log_dir / f'{name}_{timestamp}.log'
    
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(level)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    
    logger.info(f"日志记录器已设置，日志文件: {log_file}")
    
    return logger


def get_logger(name: str) -> logging.Logger:
    """获取已存在的日志记录器
    
    Args:
        name: 日志记录器名称
        
    Returns:
        日志记录器
    """
    return logging.getLogger(name)


class TqdmLoggingHandler(logging.Handler):
    """与tqdm兼容的日志处理器"""
    
    def __init__(self, level=logging.NOTSET):
        super().__init__(level)
        
    def emit(self, record):
        try:
            from tqdm import tqdm
            msg = self.format(record)
            tqdm.write(msg)
        except ImportError:
            # 如果没有tqdm，回退到标准输出
            print(self.format(record))
        except Exception:
            self.handleError(record)


def setup_tqdm_logger(name: str, log_dir: str, level: int = logging.INFO) -> logging.Logger:
    """设置与tqdm兼容的日志记录器
    
    Args:
        name: 日志记录器名称
        log_dir: 日志文件目录
        level: 日志级别
        
    Returns:
        配置好的日志记录器
    """
    # 创建日志目录
    log_dir = Path(log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    
    # 创建日志记录器
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # 避免重复添加处理器
    if logger.handlers:
        return logger
    
    # 创建格式器
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # tqdm兼容的控制台处理器
    console_handler = TqdmLoggingHandler(level)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # 文件处理器
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = log_dir / f'{name}_{timestamp}.log'
    
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(level)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    
    logger.info(f"tqdm兼容日志记录器已设置，日志文件: {log_file}")
    
    return logger


class MetricsLogger:
    """指标记录器"""
    
    def __init__(self, log_file: str):
        self.log_file = Path(log_file)
        self.log_file.parent.mkdir(parents=True, exist_ok=True)
        
        # 写入表头
        if not self.log_file.exists():
            with open(self.log_file, 'w', encoding='utf-8') as f:
                f.write('timestamp,epoch,step,metric_name,metric_value\n')
                
    def log_metric(self, epoch: int, step: int, metric_name: str, metric_value: float):
        """记录指标
        
        Args:
            epoch: 训练轮次
            step: 训练步数
            metric_name: 指标名称
            metric_value: 指标值
        """
        timestamp = datetime.now().isoformat()
        
        with open(self.log_file, 'a', encoding='utf-8') as f:
            f.write(f'{timestamp},{epoch},{step},{metric_name},{metric_value}\n')
            
    def log_metrics(self, epoch: int, step: int, metrics: dict):
        """批量记录指标
        
        Args:
            epoch: 训练轮次
            step: 训练步数
            metrics: 指标字典
        """
        for metric_name, metric_value in metrics.items():
            if isinstance(metric_value, (int, float)):
                self.log_metric(epoch, step, metric_name, metric_value)


def log_system_info(logger: logging.Logger):
    """记录系统信息
    
    Args:
        logger: 日志记录器
    """
    import torch
    import platform
    import psutil
    
    logger.info("=== 系统信息 ===")
    logger.info(f"Python版本: {sys.version}")
    logger.info(f"PyTorch版本: {torch.__version__}")
    logger.info(f"操作系统: {platform.system()} {platform.release()}")
    logger.info(f"CPU: {platform.processor()}")
    logger.info(f"CPU核心数: {psutil.cpu_count()}")
    logger.info(f"内存: {psutil.virtual_memory().total / (1024**3):.1f} GB")
    
    if torch.cuda.is_available():
        logger.info(f"CUDA版本: {torch.version.cuda}")
        logger.info(f"GPU数量: {torch.cuda.device_count()}")
        for i in range(torch.cuda.device_count()):
            gpu_name = torch.cuda.get_device_name(i)
            gpu_memory = torch.cuda.get_device_properties(i).total_memory / (1024**3)
            logger.info(f"GPU {i}: {gpu_name} ({gpu_memory:.1f} GB)")
    else:
        logger.info("CUDA不可用")
    
    logger.info("=== 系统信息结束 ===")