import os
import json
import torch
import numpy as np
from PIL import Image
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from typing import Dict, List, Tuple, Optional
import h5py
from collections import defaultdict
import random
import subprocess
import sys


class HuggingFaceVisualGenomeDataset(Dataset):
    """
    使用 Hugging Face datasets 库的 Visual Genome 数据集，用于场景图生成任务
    """
    
    def __init__(
        self,
        split: str = "train",
        image_size: Tuple[int, int] = (224, 224),
        max_objects: int = 100,
        transform: Optional[transforms.Compose] = None,
        max_samples: Optional[int] = None
    ):
        self.split = split
        self.image_size = image_size
        self.max_objects = max_objects
        self.max_samples = max_samples
        
        # 图像预处理
        if transform is None:
            self.transform = transforms.Compose([
                transforms.Resize(image_size),
                transforms.ToTensor(),
                transforms.Normalize(
                    mean=[0.485, 0.456, 0.406],
                    std=[0.229, 0.224, 0.225]
                )
            ])
        else:
            self.transform = transform
            
        # 加载数据
        self._load_data()
        
    def _load_data(self):
        """使用 GBC10M 数据集加载数据"""
        try:
            from datasets import load_dataset
            
            print("正在加载 GBC10M 数据集...")
            
            # 加载 GBC10M 数据集
            try:
                dataset = load_dataset("graph-based-captions/GBC10M", split=self.split)
                
                # 如果设置了最大样本数，则限制数据集大小
                if self.max_samples and self.max_samples < len(dataset):
                    dataset = dataset.select(range(self.max_samples))
                
                print(f"成功加载 GBC10M 数据集，包含 {len(dataset)} 个样本")
                
                # 直接使用 dataset，避免一次性加载所有数据到内存
                self.data = dataset
                print(f"数据集加载完成，包含 {len(self.data)} 个样本")
                
                # 检查数据结构
                if len(self.data) > 0:
                    sample = self.data[0]
                    print(f"数据集样本字段: {list(sample.keys())}")
                    print(f"样本示例: {sample}")
                
            except Exception as e:
                print(f"加载 GBC10M 数据集失败: {e}")
                print("可能需要登录 Hugging Face: huggingface-cli login")
                print("创建模拟数据用于演示...")
                self._create_mock_data()
                
        except Exception as e:
            print(f"加载数据集时出错: {e}")
            self._create_mock_data()
        
        # 创建词汇表
        self._build_vocabularies()
    
    def _create_mock_data(self):
        """创建模拟数据集"""
        import numpy as np
        from PIL import Image
        
        num_samples = self.max_samples if self.max_samples else 100
        
        mock_data = []
        for i in range(num_samples):
            # 创建模拟图像 (随机RGB图像)
            image = Image.fromarray(np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8))
            
            # 创建模拟数据结构，类似于 Visual Genome 格式
            sample = {
                'image': image,
                'image_id': i + 1,
                'url': f'https://example.com/image_{i+1}.jpg',
                'width': 224,
                'height': 224,
                'coco_id': None,
                'flickr_id': None,
                'regions': [
                    {
                        'region_id': i * 10 + j,
                        'image_id': i + 1,
                        'phrase': f'mock object {j} in image {i+1}',
                        'x': np.random.randint(0, 150),
                        'y': np.random.randint(0, 150),
                        'width': np.random.randint(20, 74),
                        'height': np.random.randint(20, 74)
                    } for j in range(3)  # 每个图像3个区域
                ]
            }
            mock_data.append(sample)
        
        # 将模拟数据转换为类似 datasets 的格式
        class MockDataset:
            def __init__(self, data):
                self.data = data
            
            def __len__(self):
                return len(self.data)
            
            def __getitem__(self, idx):
                return self.data[idx]
            
            def __iter__(self):
                return iter(self.data)
        
        self.data = MockDataset(mock_data)
        print(f"创建了包含 {len(self.data)} 个样本的模拟数据集")
        
    def _build_vocabularies(self):
        """从数据集构建词汇表"""
        print("正在构建词汇表...")
        
        # 收集所有的短语描述来构建简单的词汇表
        phrases = set()
        for item in self.data:
             # 检查数据结构，GBC10M可能有不同的字段名
             if 'regions' in item:
                 for region in item['regions']:
                     phrase = region['phrase'].lower().strip()
                     phrases.add(phrase)
             elif 'vertices' in item:
                 # GBC10M使用vertices字段
                 for vertex in item['vertices']:
                     descs = vertex.get('descs', [])
                     for desc in descs:
                         if desc.get('label') == 'short':
                             phrase = desc.get('text', '').lower().strip()
                             phrases.add(phrase)
             elif 'caption' in item:
                 # 如果是caption字段，直接使用
                 phrase = item['caption'].lower().strip()
                 phrases.add(phrase)
             elif 'text' in item:
                 # 如果是text字段
                 phrase = item['text'].lower().strip()
                 phrases.add(phrase)
                
        # 创建简单的对象类别（从短语中提取常见词汇）
        common_objects = [
            'person', 'man', 'woman', 'child', 'boy', 'girl',
            'car', 'truck', 'bus', 'motorcycle', 'bicycle',
            'tree', 'building', 'house', 'window', 'door',
            'table', 'chair', 'bed', 'sofa', 'tv',
            'dog', 'cat', 'bird', 'horse', 'cow',
            'sky', 'cloud', 'grass', 'road', 'water',
            'shirt', 'pants', 'hat', 'shoes', 'bag',
            'food', 'plate', 'cup', 'bottle', 'book'
        ]
        
        # 创建简单的关系词汇
        common_predicates = [
            'on', 'in', 'under', 'above', 'below', 'next to',
            'behind', 'in front of', 'wearing', 'holding',
            'sitting on', 'standing on', 'lying on',
            'has', 'is', 'contains', 'near', 'far from'
        ]
        
        # 创建简单的属性词汇
        common_attributes = [
            'red', 'blue', 'green', 'yellow', 'black', 'white',
            'big', 'small', 'large', 'tall', 'short',
            'old', 'new', 'clean', 'dirty', 'bright', 'dark'
        ]
        
        self.object_classes = ['background'] + common_objects
        self.predicate_classes = ['none'] + common_predicates
        self.attribute_classes = common_attributes
        
        # 创建类别到索引的映射
        self.obj_to_idx = {obj: idx for idx, obj in enumerate(self.object_classes)}
        self.pred_to_idx = {pred: idx for idx, pred in enumerate(self.predicate_classes)}
        self.attr_to_idx = {attr: idx for idx, attr in enumerate(self.attribute_classes)}

    def get_image_info(self, idx: int) -> Dict:
        """获取指定索引的图像信息"""
        item = self.data[idx]
        return {
            'path': item.get('img_path', item.get('img_url', ''))
        }
        
    def _extract_objects_from_regions(self, regions: List[Dict]) -> List[Dict]:
        """从区域描述中提取对象信息"""
        objects = []
        
        for i, region in enumerate(regions[:self.max_objects]):
            # 简单的对象提取：使用区域的边界框和描述
            phrase = region['phrase'].lower()
            
            # 尝试匹配已知的对象类别
            obj_class = 0  # 默认为 background
            for obj_name, obj_idx in self.obj_to_idx.items():
                if obj_name in phrase:
                    obj_class = obj_idx
                    break
                    
            # 提取属性
            attributes = []
            for attr_name, attr_idx in self.attr_to_idx.items():
                if attr_name in phrase:
                    attributes.append(attr_idx)
                    
            objects.append({
                'id': region['region_id'],
                'class': obj_class,
                'attributes': attributes,
                'bbox': [region['x'], region['y'], region['width'], region['height']]
            })
            
        return objects
        
    def _generate_relationships(self, objects: List[Dict]) -> List[Dict]:
        """生成简单的空间关系"""
        relationships = []
        
        # 简单的空间关系生成
        for i, obj1 in enumerate(objects):
            for j, obj2 in enumerate(objects):
                if i != j:
                    # 基于边界框位置生成简单关系
                    x1, y1, w1, h1 = obj1['bbox']
                    x2, y2, w2, h2 = obj2['bbox']
                    
                    # 简单的空间关系判断
                    if y1 + h1 < y2:  # obj1 在 obj2 上方
                        pred_idx = self.pred_to_idx.get('above', 0)
                    elif y2 + h2 < y1:  # obj1 在 obj2 下方
                        pred_idx = self.pred_to_idx.get('below', 0)
                    elif x1 + w1 < x2:  # obj1 在 obj2 左侧
                        pred_idx = self.pred_to_idx.get('next to', 0)
                    else:
                        pred_idx = self.pred_to_idx.get('near', 0)
                        
                    relationships.append({
                        'subject': obj1['id'],
                        'predicate': pred_idx,
                        'object': obj2['id']
                    })
                    
        return relationships[:50]  # 限制关系数量
        
    def __len__(self) -> int:
        return len(self.data)
        
    def __getitem__(self, idx: int) -> Dict:
        item = self.data[idx]
        
        # 获取图像和其他信息
        # GBC10M数据集使用img_path、img_url或image字段
        image = None
        if 'image' in item and item['image']:
            # 直接使用PIL Image对象
            image = item['image']
            if hasattr(image, 'convert'):
                image = image.convert('RGB')
        elif 'img_path' in item and item['img_path']:
            try:
                from PIL import Image
                image = Image.open(item['img_path']).convert('RGB')
            except:
                image = None
        elif 'img_url' in item and item['img_url']:
            try:
                import requests
                from PIL import Image
                from io import BytesIO
                response = requests.get(item['img_url'])
                image = Image.open(BytesIO(response.content)).convert('RGB')
            except:
                image = None
        
        # 如果图像为None，创建一个默认图像
        if image is None:
            from PIL import Image
            import numpy as np
            # 创建一个随机RGB图像作为占位符
            image = Image.fromarray(np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8))
        
        if self.transform:
            image = self.transform(image)
            
        # 从区域描述中提取对象和关系 - 处理GBC10M数据结构
        regions = item.get('regions', [])
        if not regions and 'vertices' in item:
            # GBC10M使用vertices字段
            vertices = item.get('vertices', [])
            regions = []
            for vertex in vertices:
                bbox = vertex.get('bbox', {})
                descs = vertex.get('descs', [])
                for desc in descs:
                    if desc.get('label') == 'short':
                        regions.append({
                            'region_id': vertex.get('id', 0),
                            'phrase': desc.get('text', 'unknown'),
                            'x': bbox.get('left', 0),
                            'y': bbox.get('top', 0),
                            'width': bbox.get('right', 1) - bbox.get('left', 0),
                            'height': bbox.get('bottom', 1) - bbox.get('top', 0)
                        })
        
        objects = self._extract_objects_from_regions(regions)
        relationships = self._generate_relationships(objects)
        
        scene_graph = {
            'objects': objects,
            'relationships': relationships
        }
        
        # 转换为张量格式
        # GBC10M数据集可能没有image_id字段，使用索引作为ID
        image_id = item.get('image_id', idx)
        if image_id is None:
            image_id = idx
            
        sample = {
            'image_id': image_id,
            'image': image,
            'scene_graph': self._tensorize_scene_graph(scene_graph)
        }
        
        return sample
        
    def _tensorize_scene_graph(self, scene_graph: Dict) -> Dict:
        """将场景图转换为张量格式"""
        objects = scene_graph['objects']
        relationships = scene_graph['relationships']
        
        # 对象信息
        num_objects = len(objects)
        object_classes = torch.zeros(self.max_objects, dtype=torch.long)
        object_bboxes = torch.zeros(self.max_objects, 4, dtype=torch.float32)
        object_attributes = torch.zeros(self.max_objects, len(self.attribute_classes), dtype=torch.float32)
        object_existence = torch.zeros(self.max_objects, dtype=torch.bool)
        object_existence[:num_objects] = True
        for i, obj in enumerate(objects):
            if i >= self.max_objects:
                break
            object_classes[i] = obj['class']
            object_bboxes[i] = torch.tensor(obj['bbox'], dtype=torch.float32)
            for attr_idx in obj['attributes']:
                object_attributes[i, attr_idx] = 1.0
                
        # 关系信息
        relationship_matrix = torch.zeros(
            self.max_objects, self.max_objects, len(self.predicate_classes),
            dtype=torch.float32
        )
        
        # 创建对象ID到索引的映射
        obj_id_to_idx = {obj['id']: i for i, obj in enumerate(objects)}
        
        for rel in relationships:
            subj_id = rel['subject']
            obj_id = rel['object']
            pred_idx = rel['predicate']
            
            if subj_id in obj_id_to_idx and obj_id in obj_id_to_idx:
                subj_idx = obj_id_to_idx[subj_id]
                obj_idx = obj_id_to_idx[obj_id]
                if subj_idx < self.max_objects and obj_idx < self.max_objects:
                    relationship_matrix[subj_idx, obj_idx, pred_idx] = 1.0
                    
        return {
            'num_objects': num_objects,
            'object_classes': object_classes,
            'object_bboxes': object_bboxes,
            'object_attributes': object_attributes,
            'relationship_matrix': relationship_matrix,
            'object_existence': object_existence
        }


class VisualGenomeDataset(Dataset):
    """
    Visual Genome数据集，用于场景图生成任务
    """
    
    def __init__(
        self,
        data_root: str,
        split: str = "train",
        image_size: Tuple[int, int] = (224, 224),
        max_objects: int = 100,
        transform: Optional[transforms.Compose] = None
    ):
        self.data_root = data_root
        self.split = split
        self.image_size = image_size
        self.max_objects = max_objects
        
        # 图像预处理
        if transform is None:
            self.transform = transforms.Compose([
                transforms.Resize(image_size),
                transforms.ToTensor(),
                transforms.Normalize(
                    mean=[0.485, 0.456, 0.406],
                    std=[0.229, 0.224, 0.225]
                )
            ])
        else:
            self.transform = transform
            
        # 加载数据
        self._load_data()
        
    def _load_data(self):
        """加载Visual Genome数据"""
        # 加载图像元数据
        image_data_path = os.path.join(self.data_root, "image_data.json")
        with open(image_data_path, 'r') as f:
            self.image_data = {img['image_id']: img for img in json.load(f)}
            
        # 加载场景图数据
        scene_graphs_path = os.path.join(self.data_root, "scene_graphs.json")
        with open(scene_graphs_path, 'r') as f:
            scene_graphs = json.load(f)
            
        # 加载词汇表
        vocab_path = os.path.join(self.data_root, "vocab.json")
        with open(vocab_path, 'r') as f:
            vocab = json.load(f)
            
        self.object_classes = vocab['object_classes']
        self.predicate_classes = vocab['predicate_classes']
        self.attribute_classes = vocab['attribute_classes']
        
        # 创建类别到索引的映射
        self.obj_to_idx = {obj: idx for idx, obj in enumerate(self.object_classes)}
        self.pred_to_idx = {pred: idx for idx, pred in enumerate(self.predicate_classes)}
        self.attr_to_idx = {attr: idx for idx, attr in enumerate(self.attribute_classes)}
        
        # 加载数据分割
        split_path = os.path.join(self.data_root, f"{self.split}_split.json")
        with open(split_path, 'r') as f:
            self.image_ids = json.load(f)
            
        # 处理场景图数据
        self.scene_graphs = {}
        for sg in scene_graphs:
            if sg['image_id'] in self.image_ids:
                self.scene_graphs[sg['image_id']] = self._process_scene_graph(sg)
                
        # 过滤掉没有场景图的图像
        self.image_ids = [img_id for img_id in self.image_ids if img_id in self.scene_graphs]
        
    def _process_scene_graph(self, scene_graph: Dict) -> Dict:
        """处理单个场景图"""
        objects = []
        relationships = []
        
        # 处理对象
        for obj in scene_graph.get('objects', []):
            obj_class = obj.get('name', 'unknown')
            if obj_class in self.obj_to_idx:
                # 处理属性
                attributes = []
                for attr in obj.get('attributes', []):
                    if attr in self.attr_to_idx:
                        attributes.append(self.attr_to_idx[attr])
                        
                objects.append({
                    'id': obj['object_id'],
                    'class': self.obj_to_idx[obj_class],
                    'attributes': attributes,
                    'bbox': [obj['x'], obj['y'], obj['w'], obj['h']]
                })
                
        # 处理关系
        for rel in scene_graph.get('relationships', []):
            predicate = rel.get('predicate', 'unknown')
            if predicate in self.pred_to_idx:
                relationships.append({
                    'subject': rel['subject_id'],
                    'predicate': self.pred_to_idx[predicate],
                    'object': rel['object_id']
                })
                
        return {
            'objects': objects[:self.max_objects],
            'relationships': relationships
        }
        
    def __len__(self) -> int:
        return len(self.image_ids)
        
    def __getitem__(self, idx: int) -> Dict:
        image_id = self.image_ids[idx]
        
        # 加载图像
        image_path = os.path.join(
            self.data_root, "images", f"{image_id}.jpg"
        )
        image = Image.open(image_path).convert('RGB')
        
        if self.transform:
            image = self.transform(image)
            
        # 获取场景图
        scene_graph = self.scene_graphs[image_id]
        
        # 转换为张量格式
        sample = {
            'image_id': image_id,
            'image': image,
            'scene_graph': self._tensorize_scene_graph(scene_graph)
        }
        
        return sample
        
    def _tensorize_scene_graph(self, scene_graph: Dict) -> Dict:
        """将场景图转换为张量格式"""
        objects = scene_graph['objects']
        relationships = scene_graph['relationships']
        
        # 对象信息
        num_objects = len(objects)
        object_classes = torch.zeros(self.max_objects, dtype=torch.long)
        object_bboxes = torch.zeros(self.max_objects, 4, dtype=torch.float32)
        object_attributes = torch.zeros(self.max_objects, len(self.attribute_classes), dtype=torch.float32)
        object_existence = torch.zeros(self.max_objects, dtype=torch.bool)
        object_existence[:num_objects] = True
        
        for i, obj in enumerate(objects):
            if i >= self.max_objects:
                break
            object_classes[i] = obj['class']
            object_bboxes[i] = torch.tensor(obj['bbox'], dtype=torch.float32)
            for attr_idx in obj['attributes']:
                object_attributes[i, attr_idx] = 1.0
                
        # 关系信息
        # 创建关系矩阵 (max_objects, max_objects, num_predicates)
        relationship_matrix = torch.zeros(
            self.max_objects, self.max_objects, len(self.predicate_classes),
            dtype=torch.float32
        )
        
        # 创建对象ID到索引的映射
        obj_id_to_idx = {obj['id']: i for i, obj in enumerate(objects)}
        
        for rel in relationships:
            subj_id = rel['subject']
            obj_id = rel['object']
            pred_idx = rel['predicate']
            
            if subj_id in obj_id_to_idx and obj_id in obj_id_to_idx:
                subj_idx = obj_id_to_idx[subj_id]
                obj_idx = obj_id_to_idx[obj_id]
                if subj_idx < self.max_objects and obj_idx < self.max_objects:
                    relationship_matrix[subj_idx, obj_idx, pred_idx] = 1.0
                    
        return {
            'num_objects': num_objects,
            'object_classes': object_classes,
            'object_bboxes': object_bboxes,
            'object_attributes': object_attributes,
            'relationship_matrix': relationship_matrix,
            'object_existence': object_existence
        }


def collate_fn(batch: List[Dict]) -> Dict:
    """自定义的批处理函数"""
    images = torch.stack([item['image'] for item in batch])
    image_ids = [item['image_id'] for item in batch]
    
    # 收集场景图信息
    batch_size = len(batch)
    max_objects = batch[0]['scene_graph']['object_classes'].size(0)
    num_predicates = batch[0]['scene_graph']['relationship_matrix'].size(2)
    num_attributes = batch[0]['scene_graph']['object_attributes'].size(1)
    
    # 批量张量
    num_objects = torch.tensor([item['scene_graph']['num_objects'] for item in batch])
    object_classes = torch.stack([item['scene_graph']['object_classes'] for item in batch])
    object_bboxes = torch.stack([item['scene_graph']['object_bboxes'] for item in batch])
    object_attributes = torch.stack([item['scene_graph']['object_attributes'] for item in batch])
    relationship_matrix = torch.stack([item['scene_graph']['relationship_matrix'] for item in batch])
    object_existence = torch.stack([item['scene_graph']['object_existence'] for item in batch])
    
    return {
        'image_id': image_ids,
        'image': images,
        'scene_graph': {
            'num_objects': num_objects,
            'object_classes': object_classes,
            'object_bboxes': object_bboxes,
            'object_attributes': object_attributes,
            'relationship_matrix': relationship_matrix,
            'object_existence': object_existence
        }
    }


def create_dataloader(
    data_root: str,
    split: str,
    batch_size: int,
    image_size: Tuple[int, int] = (224, 224),
    max_objects: int = 100,
    num_workers: int = 4,
    pin_memory: bool = True,
    shuffle: bool = None,
    prefetch_factor: int = 2
) -> DataLoader:
    """创建数据加载器"""
    if shuffle is None:
        shuffle = (split == 'train')
        
    dataset = VisualGenomeDataset(
        data_root=data_root,
        split=split,
        image_size=image_size,
        max_objects=max_objects
    )
    
    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=pin_memory,
        collate_fn=collate_fn,
        drop_last=(split == 'train')
    )
    
    return dataloader


def create_huggingface_dataloader(
    split: str,
    batch_size: int,
    image_size: Tuple[int, int] = (224, 224),
    max_objects: int = 100,
    num_workers: int = 4,
    pin_memory: bool = True,
    shuffle: bool = None,
    max_samples: Optional[int] = None
) -> DataLoader:
    """创建使用 Hugging Face datasets 的数据加载器"""
    if shuffle is None:
        shuffle = (split == 'train')
        
    dataset = HuggingFaceVisualGenomeDataset(
        split=split,
        image_size=image_size,
        max_objects=max_objects,
        max_samples=max_samples
    )
    
    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=pin_memory,
        collate_fn=collate_fn,
        drop_last=(split == 'train')
    )
    
    return dataloader