import os
import json
import urllib.request
import zipfile
import argparse
from collections import Counter, defaultdict
from typing import Dict, List, Set
import numpy as np
from tqdm import tqdm


def download_visual_genome(data_root: str):
    """下载Visual Genome数据集"""
    os.makedirs(data_root, exist_ok=True)
    
    # Visual Genome数据集的URL
    urls = {
        'image_data': 'https://cs.stanford.edu/people/rak248/VG_100K_2/image_data.json',
        'scene_graphs': 'https://cs.stanford.edu/people/rak248/VG_100K_2/scene_graphs.json',
        'objects': 'https://cs.stanford.edu/people/rak248/VG_100K_2/objects.json',
        'attributes': 'https://cs.stanford.edu/people/rak248/VG_100K_2/attributes.json',
        'relationships': 'https://cs.stanford.edu/people/rak248/VG_100K_2/relationships.json',
        'images_part1': 'https://cs.stanford.edu/people/rak248/VG_100K_2/images.zip',
        'images_part2': 'https://cs.stanford.edu/people/rak248/VG_100K_2/images2.zip'
    }
    
    print("开始下载Visual Genome数据集...")
    
    # 下载JSON文件
    for name, url in urls.items():
        if name.startswith('images'):
            continue
            
        file_path = os.path.join(data_root, f"{name}.json")
        if not os.path.exists(file_path):
            print(f"下载 {name}.json...")
            urllib.request.urlretrieve(url, file_path)
        else:
            print(f"{name}.json 已存在，跳过下载")
    
    # 下载图像
    images_dir = os.path.join(data_root, "images")
    os.makedirs(images_dir, exist_ok=True)
    
    for name, url in urls.items():
        if not name.startswith('images'):
            continue
            
        zip_path = os.path.join(data_root, f"{name}.zip")
        if not os.path.exists(zip_path):
            print(f"下载 {name}.zip...")
            urllib.request.urlretrieve(url, zip_path)
            
            print(f"解压 {name}.zip...")
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(images_dir)
                
            os.remove(zip_path)
        else:
            print(f"{name}.zip 已处理，跳过")
    
    print("Visual Genome数据集下载完成！")


def build_vocabulary(
    scene_graphs_path: str,
    min_object_freq: int = 10,
    min_predicate_freq: int = 5,
    min_attribute_freq: int = 5
) -> Dict:
    """构建词汇表"""
    print("构建词汇表...")
    
    with open(scene_graphs_path, 'r') as f:
        scene_graphs = json.load(f)
    
    # 统计频次
    object_counter = Counter()
    predicate_counter = Counter()
    attribute_counter = Counter()
    
    for sg in tqdm(scene_graphs, desc="统计词汇频次"):
        # 统计对象
        for obj in sg.get('objects', []):
            object_counter[obj.get('name', 'unknown')] += 1
            
            # 统计属性
            for attr in obj.get('attributes', []):
                attribute_counter[attr] += 1
        
        # 统计关系
        for rel in sg.get('relationships', []):
            predicate_counter[rel.get('predicate', 'unknown')] += 1
    
    # 过滤低频词汇
    object_classes = ['__background__'] + [
        obj for obj, freq in object_counter.most_common()
        if freq >= min_object_freq
    ]
    
    predicate_classes = [
        pred for pred, freq in predicate_counter.most_common()
        if freq >= min_predicate_freq
    ]
    
    attribute_classes = [
        attr for attr, freq in attribute_counter.most_common()
        if freq >= min_attribute_freq
    ]
    
    vocab = {
        'object_classes': object_classes,
        'predicate_classes': predicate_classes,
        'attribute_classes': attribute_classes
    }
    
    print(f"词汇表统计:")
    print(f"  对象类别: {len(object_classes)}")
    print(f"  谓词类别: {len(predicate_classes)}")
    print(f"  属性类别: {len(attribute_classes)}")
    
    return vocab


def create_data_splits(
    scene_graphs_path: str,
    train_ratio: float = 0.7,
    val_ratio: float = 0.15,
    test_ratio: float = 0.15,
    seed: int = 42
) -> Dict[str, List[int]]:
    """创建数据分割"""
    print("创建数据分割...")
    
    with open(scene_graphs_path, 'r') as f:
        scene_graphs = json.load(f)
    
    # 获取所有图像ID
    image_ids = [sg['image_id'] for sg in scene_graphs]
    
    # 随机打乱
    np.random.seed(seed)
    np.random.shuffle(image_ids)
    
    # 计算分割点
    total = len(image_ids)
    train_end = int(total * train_ratio)
    val_end = train_end + int(total * val_ratio)
    
    splits = {
        'train': image_ids[:train_end],
        'val': image_ids[train_end:val_end],
        'test': image_ids[val_end:]
    }
    
    print(f"数据分割统计:")
    print(f"  训练集: {len(splits['train'])}")
    print(f"  验证集: {len(splits['val'])}")
    print(f"  测试集: {len(splits['test'])}")
    
    return splits


def filter_scene_graphs(
    scene_graphs_path: str,
    vocab: Dict,
    output_path: str,
    min_objects: int = 2,
    min_relationships: int = 1
):
    """过滤场景图，只保留有效的对象和关系"""
    print("过滤场景图...")
    
    with open(scene_graphs_path, 'r') as f:
        scene_graphs = json.load(f)
    
    obj_to_idx = {obj: idx for idx, obj in enumerate(vocab['object_classes'])}
    pred_to_idx = {pred: idx for idx, pred in enumerate(vocab['predicate_classes'])}
    attr_to_idx = {attr: idx for idx, attr in enumerate(vocab['attribute_classes'])}
    
    filtered_scene_graphs = []
    
    for sg in tqdm(scene_graphs, desc="过滤场景图"):
        # 过滤对象
        valid_objects = []
        valid_object_ids = set()
        
        for obj in sg.get('objects', []):
            obj_name = obj.get('name', 'unknown')
            if obj_name in obj_to_idx:
                # 过滤属性
                valid_attributes = [
                    attr for attr in obj.get('attributes', [])
                    if attr in attr_to_idx
                ]
                
                valid_obj = {
                    'object_id': obj['object_id'],
                    'name': obj_name,
                    'attributes': valid_attributes,
                    'x': obj.get('x', 0),
                    'y': obj.get('y', 0),
                    'w': obj.get('w', 0),
                    'h': obj.get('h', 0)
                }
                
                valid_objects.append(valid_obj)
                valid_object_ids.add(obj['object_id'])
        
        # 过滤关系
        valid_relationships = []
        for rel in sg.get('relationships', []):
            pred_name = rel.get('predicate', 'unknown')
            if (pred_name in pred_to_idx and
                rel.get('subject_id') in valid_object_ids and
                rel.get('object_id') in valid_object_ids):
                
                valid_relationships.append({
                    'subject_id': rel['subject_id'],
                    'predicate': pred_name,
                    'object_id': rel['object_id']
                })
        
        # 检查是否满足最小要求
        if (len(valid_objects) >= min_objects and
            len(valid_relationships) >= min_relationships):
            
            filtered_sg = {
                'image_id': sg['image_id'],
                'objects': valid_objects,
                'relationships': valid_relationships
            }
            
            filtered_scene_graphs.append(filtered_sg)
    
    # 保存过滤后的场景图
    with open(output_path, 'w') as f:
        json.dump(filtered_scene_graphs, f)
    
    print(f"过滤完成: {len(scene_graphs)} -> {len(filtered_scene_graphs)}")


def main():
    parser = argparse.ArgumentParser(description="准备Visual Genome数据集")
    parser.add_argument('--data_root', type=str, default='./data',
                       help='数据根目录')
    parser.add_argument('--download', action='store_true',
                       help='是否下载数据集')
    parser.add_argument('--min_object_freq', type=int, default=10,
                       help='对象最小频次')
    parser.add_argument('--min_predicate_freq', type=int, default=5,
                       help='谓词最小频次')
    parser.add_argument('--min_attribute_freq', type=int, default=5,
                       help='属性最小频次')
    parser.add_argument('--train_ratio', type=float, default=0.7,
                       help='训练集比例')
    parser.add_argument('--val_ratio', type=float, default=0.15,
                       help='验证集比例')
    parser.add_argument('--test_ratio', type=float, default=0.15,
                       help='测试集比例')
    
    args = parser.parse_args()
    
    # 创建数据目录
    os.makedirs(args.data_root, exist_ok=True)
    
    # 下载数据集
    if args.download:
        download_visual_genome(args.data_root)
    
    # 构建词汇表
    scene_graphs_path = os.path.join(args.data_root, "scene_graphs.json")
    vocab = build_vocabulary(
        scene_graphs_path,
        args.min_object_freq,
        args.min_predicate_freq,
        args.min_attribute_freq
    )
    
    # 保存词汇表
    vocab_path = os.path.join(args.data_root, "vocab.json")
    with open(vocab_path, 'w') as f:
        json.dump(vocab, f, indent=2)
    
    # 过滤场景图
    filtered_scene_graphs_path = os.path.join(args.data_root, "scene_graphs_filtered.json")
    filter_scene_graphs(scene_graphs_path, vocab, filtered_scene_graphs_path)
    
    # 创建数据分割
    splits = create_data_splits(
        filtered_scene_graphs_path,
        args.train_ratio,
        args.val_ratio,
        args.test_ratio
    )
    
    # 保存数据分割
    for split_name, image_ids in splits.items():
        split_path = os.path.join(args.data_root, f"{split_name}_split.json")
        with open(split_path, 'w') as f:
            json.dump(image_ids, f)
    
    print("数据准备完成！")


if __name__ == "__main__":
    main()