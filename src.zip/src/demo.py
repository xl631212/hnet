import os
import json
import argparse
from pathlib import Path
from typing import Dict, List, Optional
import time

import torch
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import FancyBboxPatch
import networkx as nx
import cv2

from src.models.scene_graph_hnet import SceneGraphHNet
from src.utils.checkpoint import load_checkpoint
from src.utils.logger import setup_logger


class SceneGraphDemo:
    """场景图生成演示"""
    
    def __init__(self, config_path: str, checkpoint_path: str):
        # 加载配置
        with open(config_path, 'r', encoding='utf-8') as f:
            self.config = json.load(f)
            
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # 设置日志
        self.logger = setup_logger('demo', self.config['logging']['log_dir'])
        self.logger.info(f"使用设备: {self.device}")
        
        # 加载模型
        self.model = SceneGraphHNet(self.config).to(self.device)
        self._load_model(checkpoint_path)
        
        # 加载词汇表
        self._load_vocabularies()
        
        # 评估阈值
        self.object_threshold = self.config['evaluation']['object_threshold']
        self.attribute_threshold = self.config['evaluation']['attribute_threshold']
        self.relationship_threshold = self.config['evaluation']['relationship_threshold']
        
    def _load_model(self, checkpoint_path: str):
        """加载模型权重"""
        self.logger.info(f"加载模型: {checkpoint_path}")
        
        checkpoint = load_checkpoint(checkpoint_path, self.device)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.model.eval()
        
        self.logger.info("模型加载完成")
        
    def _load_vocabularies(self):
        """加载词汇表"""
        data_dir = Path(self.config['data']['data_dir'])
        
        # 加载对象词汇表
        with open(data_dir / 'object_vocab.json', 'r', encoding='utf-8') as f:
            self.object_vocab = json.load(f)
        self.idx_to_object = {v: k for k, v in self.object_vocab.items()}
        
        # 加载谓词词汇表
        with open(data_dir / 'predicate_vocab.json', 'r', encoding='utf-8') as f:
            self.predicate_vocab = json.load(f)
        self.idx_to_predicate = {v: k for k, v in self.predicate_vocab.items()}
        
        # 加载属性词汇表
        with open(data_dir / 'attribute_vocab.json', 'r', encoding='utf-8') as f:
            self.attribute_vocab = json.load(f)
        self.idx_to_attribute = {v: k for k, v in self.attribute_vocab.items()}
        
        self.logger.info("词汇表加载完成")
        
    def preprocess_image(self, image_path: str) -> torch.Tensor:
        """预处理图像"""
        import torchvision.transforms as transforms
        
        image = Image.open(image_path).convert('RGB')
        
        transform = transforms.Compose([
            transforms.Resize((self.config['model']['image_size'], self.config['model']['image_size'])),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        
        return transform(image).unsqueeze(0)
        
    def predict_scene_graph(self, image_path: str) -> Dict:
        """预测场景图
        
        Args:
            image_path: 图像路径
            
        Returns:
            预测的场景图
        """
        # 预处理图像
        image_tensor = self.preprocess_image(image_path).to(self.device)
        
        # 预测
        start_time = time.time()
        
        with torch.no_grad():
            predictions = self.model(image_tensor)
            
        inference_time = time.time() - start_time
        
        # 解析场景图
        scene_graph = self._parse_predictions(predictions)
        scene_graph['inference_time'] = inference_time
        
        return scene_graph
        
    def _parse_predictions(self, predictions: Dict) -> Dict:
        """解析模型预测结果"""
        # 获取预测结果
        object_existence = torch.sigmoid(predictions['object_existence'][0])  # (max_objects,)
        object_logits = predictions['object_logits'][0]  # (max_objects, num_classes)
        attribute_logits = predictions['attribute_logits'][0]  # (max_objects, num_attributes)
        relationship_logits = predictions['relationship_logits'][0]  # (max_objects, max_objects, num_predicates)
        
        # 解析对象
        object_mask = object_existence > self.object_threshold
        object_indices = torch.where(object_mask)[0]
        
        objects = []
        for idx in object_indices:
            obj_class_idx = torch.argmax(object_logits[idx]).item()
            obj_class = self.idx_to_object.get(obj_class_idx, f"unknown_{obj_class_idx}")
            obj_confidence = torch.softmax(object_logits[idx], dim=0)[obj_class_idx].item()
            
            # 获取属性
            attr_probs = torch.sigmoid(attribute_logits[idx])
            attr_indices = torch.where(attr_probs > self.attribute_threshold)[0]
            attributes = []
            
            for attr_idx in attr_indices:
                attr_name = self.idx_to_attribute.get(attr_idx.item(), f"unknown_{attr_idx.item()}")
                attr_conf = attr_probs[attr_idx].item()
                attributes.append({
                    'name': attr_name,
                    'confidence': attr_conf
                })
                
            objects.append({
                'id': idx.item(),
                'class': obj_class,
                'confidence': obj_confidence,
                'attributes': attributes
            })
            
        # 解析关系
        relationships = []
        for i, idx_i in enumerate(object_indices):
            for j, idx_j in enumerate(object_indices):
                if i != j:
                    rel_probs = torch.sigmoid(relationship_logits[idx_i, idx_j])
                    rel_indices = torch.where(rel_probs > self.relationship_threshold)[0]
                    
                    for rel_idx in rel_indices:
                        pred_name = self.idx_to_predicate.get(rel_idx.item(), f"unknown_{rel_idx.item()}")
                        pred_conf = rel_probs[rel_idx].item()
                        
                        relationships.append({
                            'subject': idx_i.item(),
                            'predicate': pred_name,
                            'object': idx_j.item(),
                            'confidence': pred_conf
                        })
                        
        return {
            'objects': objects,
            'relationships': relationships
        }
        
    def visualize_scene_graph(self, image_path: str, scene_graph: Dict, output_path: str):
        """可视化场景图"""
        # 加载原始图像
        image = Image.open(image_path).convert('RGB')
        
        # 创建图形
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))
        
        # 显示原始图像
        ax1.imshow(image)
        ax1.set_title('原始图像', fontsize=14, fontweight='bold')
        ax1.axis('off')
        
        # 在图像上标注对象
        self._annotate_objects_on_image(ax1, scene_graph['objects'], image.size)
        
        # 绘制场景图
        self._draw_scene_graph(ax2, scene_graph)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        self.logger.info(f"可视化结果已保存到: {output_path}")
        
    def _annotate_objects_on_image(self, ax, objects: List[Dict], image_size: tuple):
        """在图像上标注对象"""
        # 简化版本：在图像上随机放置对象标签
        # 实际应用中，这里应该使用对象检测的边界框信息
        
        width, height = image_size
        colors = plt.cm.Set3(np.linspace(0, 1, len(objects)))
        
        for i, obj in enumerate(objects):
            # 随机位置（实际应该使用真实的边界框）
            x = np.random.randint(0, width - 100)
            y = np.random.randint(0, height - 50)
            
            # 创建标签文本
            label = obj['class']
            if obj['attributes']:
                top_attrs = sorted(obj['attributes'], key=lambda x: x['confidence'], reverse=True)[:2]
                attr_names = [attr['name'] for attr in top_attrs]
                label = f"{', '.join(attr_names)} {label}"
                
            # 添加边界框和标签
            bbox = FancyBboxPatch(
                (x, y), 100, 30,
                boxstyle="round,pad=0.1",
                facecolor=colors[i],
                edgecolor='black',
                alpha=0.7
            )
            ax.add_patch(bbox)
            
            ax.text(x + 50, y + 15, label, 
                   ha='center', va='center', 
                   fontsize=10, fontweight='bold')
                   
    def _draw_scene_graph(self, ax, scene_graph: Dict):
        """绘制场景图"""
        # 创建网络图
        G = nx.DiGraph()
        
        # 添加节点（对象）
        for obj in scene_graph['objects']:
            label = obj['class']
            if obj['attributes']:
                top_attrs = sorted(obj['attributes'], key=lambda x: x['confidence'], reverse=True)[:2]
                attr_names = [attr['name'] for attr in top_attrs]
                label = f"{', '.join(attr_names)}\n{label}"
                
            G.add_node(obj['id'], label=label, confidence=obj['confidence'])
            
        # 添加边（关系）
        for rel in scene_graph['relationships']:
            G.add_edge(
                rel['subject'], 
                rel['object'],
                label=rel['predicate'],
                confidence=rel['confidence']
            )
            
        if len(G.nodes()) == 0:
            ax.text(0.5, 0.5, '未检测到对象', ha='center', va='center', 
                   transform=ax.transAxes, fontsize=14)
            ax.set_title('场景图', fontsize=14, fontweight='bold')
            ax.axis('off')
            return
            
        # 布局
        if len(G.nodes()) == 1:
            pos = {list(G.nodes())[0]: (0, 0)}
        else:
            pos = nx.spring_layout(G, k=2, iterations=50)
            
        # 绘制节点
        node_colors = ['lightblue' for _ in G.nodes()]
        node_sizes = [3000 for _ in G.nodes()]
        
        nx.draw_networkx_nodes(G, pos, ax=ax,
                              node_color=node_colors,
                              node_size=node_sizes,
                              alpha=0.8)
        
        # 绘制边
        nx.draw_networkx_edges(G, pos, ax=ax,
                              edge_color='gray',
                              arrows=True,
                              arrowsize=20,
                              arrowstyle='->')
        
        # 添加节点标签
        node_labels = {node: data['label'] for node, data in G.nodes(data=True)}
        nx.draw_networkx_labels(G, pos, node_labels, ax=ax,
                               font_size=8, font_weight='bold')
        
        # 添加边标签
        edge_labels = {(u, v): data['label'] for u, v, data in G.edges(data=True)}
        nx.draw_networkx_edge_labels(G, pos, edge_labels, ax=ax,
                                    font_size=8, font_color='red')
        
        ax.set_title('场景图', fontsize=14, fontweight='bold')
        ax.axis('off')
        
    def generate_json_output(self, scene_graph: Dict) -> str:
        """生成JSON格式的输出"""
        # 转换为标准格式
        output = {
            'objects': [],
            'relationships': []
        }
        
        # 添加对象
        for obj in scene_graph['objects']:
            obj_data = {
                'id': obj['id'],
                'class': obj['class'],
                'confidence': round(obj['confidence'], 4),
                'attributes': [attr['name'] for attr in obj['attributes']]
            }
            output['objects'].append(obj_data)
            
        # 添加关系
        for rel in scene_graph['relationships']:
            rel_data = {
                'subject': rel['subject'],
                'predicate': rel['predicate'],
                'object': rel['object'],
                'confidence': round(rel['confidence'], 4)
            }
            output['relationships'].append(rel_data)
            
        return json.dumps(output, indent=2, ensure_ascii=False)
        
    def run_demo(self, image_path: str, output_dir: str = './demo_output'):
        """运行完整演示"""
        output_dir = Path(output_dir)
        output_dir.mkdir(exist_ok=True)
        
        self.logger.info(f"开始处理图像: {image_path}")
        
        # 预测场景图
        scene_graph = self.predict_scene_graph(image_path)
        
        # 生成可视化
        vis_path = output_dir / f'visualization_{Path(image_path).stem}.png'
        self.visualize_scene_graph(image_path, scene_graph, str(vis_path))
        
        # 保存JSON结果
        json_output = self.generate_json_output(scene_graph)
        json_path = output_dir / f'scene_graph_{Path(image_path).stem}.json'
        
        with open(json_path, 'w', encoding='utf-8') as f:
            f.write(json_output)
            
        # 打印结果
        print(f"\n=== 场景图生成结果 ===")
        print(f"图像: {image_path}")
        print(f"推理时间: {scene_graph['inference_time']:.3f}秒")
        print(f"检测到 {len(scene_graph['objects'])} 个对象")
        print(f"检测到 {len(scene_graph['relationships'])} 个关系")
        print(f"\n场景图JSON:")
        print(json_output)
        print(f"\n结果已保存到:")
        print(f"  可视化: {vis_path}")
        print(f"  JSON: {json_path}")
        
        return scene_graph


def main():
    parser = argparse.ArgumentParser(description='场景图生成演示')
    parser.add_argument('--config', type=str, required=True, help='配置文件路径')
    parser.add_argument('--checkpoint', type=str, required=True, help='模型检查点路径')
    parser.add_argument('--image', type=str, required=True, help='输入图像路径')
    parser.add_argument('--output', type=str, default='./demo_output', help='输出目录')
    parser.add_argument('--gpu', type=int, help='使用的GPU ID')
    
    args = parser.parse_args()
    
    # 设置GPU
    if args.gpu is not None:
        os.environ['CUDA_VISIBLE_DEVICES'] = str(args.gpu)
        
    # 检查输入文件
    if not os.path.exists(args.image):
        print(f"错误: 图像文件不存在: {args.image}")
        return
        
    if not os.path.exists(args.config):
        print(f"错误: 配置文件不存在: {args.config}")
        return
        
    if not os.path.exists(args.checkpoint):
        print(f"错误: 检查点文件不存在: {args.checkpoint}")
        return
        
    # 创建演示器并运行
    try:
        demo = SceneGraphDemo(args.config, args.checkpoint)
        demo.run_demo(args.image, args.output)
    except Exception as e:
        print(f"演示运行失败: {e}")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    main()