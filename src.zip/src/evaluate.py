import os
import json
import argparse
from pathlib import Path
from typing import Dict, List
import time

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from src.data.dataset import VisualGenomeDataset, create_dataloader
from src.models.scene_graph_hnet import SceneGraphHNet
from src.evaluation.metrics import SceneGraphMetrics
from src.utils.checkpoint import load_checkpoint
from src.utils.logger import setup_logger


class Evaluator:
    """场景图生成评估器"""
    
    def __init__(self, config: Dict, checkpoint_path: str):
        self.config = config
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # 设置日志
        self.logger = setup_logger('evaluator', config['logging']['log_dir'])
        self.logger.info(f"使用设备: {self.device}")
        
        # 创建输出目录
        self.output_dir = Path(config['evaluation']['output_dir'])
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # 加载模型
        self.model = SceneGraphHNet(config).to(self.device)
        self._load_model(checkpoint_path)
        
        # 初始化评估指标
        self.metrics = SceneGraphMetrics(config)
        
        # 加载词汇表
        self._load_vocabularies()
        
    def _load_model(self, checkpoint_path: str):
        """加载模型权重"""
        self.logger.info(f"加载模型: {checkpoint_path}")
        
        checkpoint = load_checkpoint(checkpoint_path, self.device)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.model.eval()
        
        self.logger.info("模型加载完成")
        
    def _load_vocabularies(self):
        """加载词汇表"""
        data_dir = Path(self.config['data']['data_dir'])
        
        # 加载对象词汇表
        with open(data_dir / 'object_vocab.json', 'r', encoding='utf-8') as f:
            self.object_vocab = json.load(f)
        self.idx_to_object = {v: k for k, v in self.object_vocab.items()}
        
        # 加载谓词词汇表
        with open(data_dir / 'predicate_vocab.json', 'r', encoding='utf-8') as f:
            self.predicate_vocab = json.load(f)
        self.idx_to_predicate = {v: k for k, v in self.predicate_vocab.items()}
        
        # 加载属性词汇表
        with open(data_dir / 'attribute_vocab.json', 'r', encoding='utf-8') as f:
            self.attribute_vocab = json.load(f)
        self.idx_to_attribute = {v: k for k, v in self.attribute_vocab.items()}
        
        self.logger.info("词汇表加载完成")
        
    def evaluate_dataset(self, split: str = 'test') -> Dict[str, float]:
        """评估数据集
        
        Args:
            split: 数据集分割 ('train', 'val', 'test')
            
        Returns:
            评估指标字典
        """
        self.logger.info(f"开始评估 {split} 数据集")
        
        # 创建数据集
        dataset = VisualGenomeDataset(
            data_dir=self.config['data']['data_dir'],
            split=split,
            config=self.config
        )
        
        dataloader = create_dataloader(
            dataset,
            batch_size=self.config['evaluation']['batch_size'],
            shuffle=False,
            num_workers=self.config['data']['num_workers'],
            pin_memory=True
        )
        
        self.logger.info(f"数据集大小: {len(dataset)}")
        
        # 收集预测和目标
        all_predictions = []
        all_targets = []
        
        start_time = time.time()
        
        with torch.no_grad():
            for batch_idx, batch in enumerate(tqdm(dataloader, desc=f"评估{split}数据集")):
                images = batch['image'].to(self.device)
                scene_graphs = {
                    k: v.to(self.device) if isinstance(v, torch.Tensor) else v
                    for k, v in batch['scene_graph'].items()
                }
                
                # 前向传播
                predictions = self.model(images)
                
                # 收集结果
                all_predictions.append({
                    k: v.cpu() if isinstance(v, torch.Tensor) else v
                    for k, v in predictions.items()
                })
                all_targets.append({
                    k: v.cpu() if isinstance(v, torch.Tensor) else v
                    for k, v in scene_graphs.items()
                })
                
        eval_time = time.time() - start_time
        self.logger.info(f"评估完成，耗时: {eval_time:.2f}秒")
        
        # 计算指标
        metrics = self.metrics.compute_metrics(all_predictions, all_targets)
        
        # 记录结果
        self.logger.info(self.metrics.format_results(metrics))
        
        # 保存详细结果
        self._save_detailed_results(all_predictions, all_targets, metrics, split)
        
        return metrics
        
    def _save_detailed_results(self, predictions: List[Dict], targets: List[Dict], 
                             metrics: Dict[str, float], split: str):
        """保存详细的评估结果"""
        results_dir = self.output_dir / f'{split}_results'
        results_dir.mkdir(exist_ok=True)
        
        # 保存指标
        with open(results_dir / 'metrics.json', 'w', encoding='utf-8') as f:
            json.dump(metrics, f, indent=2, ensure_ascii=False)
            
        # 保存一些样本的预测结果
        sample_results = []
        num_samples = min(10, len(predictions))
        
        for i in range(num_samples):
            pred_sg = self.metrics._parse_scene_graph(predictions[i])
            target_sg = self.metrics._parse_scene_graph_from_target(targets[i])
            
            # 转换为可读格式
            pred_readable = self._convert_to_readable(pred_sg)
            target_readable = self._convert_to_readable(target_sg)
            
            sample_results.append({
                'sample_id': i,
                'prediction': pred_readable,
                'target': target_readable
            })
            
        with open(results_dir / 'sample_predictions.json', 'w', encoding='utf-8') as f:
            json.dump(sample_results, f, indent=2, ensure_ascii=False)
            
        # 生成可视化图表
        self._generate_visualizations(metrics, results_dir)
        
        self.logger.info(f"详细结果已保存到: {results_dir}")
        
    def _convert_to_readable(self, scene_graph: Dict) -> Dict:
        """将场景图转换为可读格式"""
        readable_objects = []
        for obj in scene_graph['objects']:
            readable_obj = {
                'id': obj['id'],
                'class': self.idx_to_object.get(obj['class'], f"unknown_{obj['class']}"),
                'attributes': [self.idx_to_attribute.get(attr, f"unknown_{attr}") 
                             for attr in obj['attributes']]
            }
            readable_objects.append(readable_obj)
            
        readable_relationships = []
        for rel in scene_graph['relationships']:
            readable_rel = {
                'subject': rel['subject'],
                'predicate': self.idx_to_predicate.get(rel['predicate'], f"unknown_{rel['predicate']}"),
                'object': rel['object']
            }
            readable_relationships.append(readable_rel)
            
        return {
            'objects': readable_objects,
            'relationships': readable_relationships
        }
        
    def _generate_visualizations(self, metrics: Dict[str, float], output_dir: Path):
        """生成可视化图表"""
        # 设置图表样式
        plt.style.use('seaborn-v0_8')
        sns.set_palette("husl")
        
        # 1. 各模块性能对比
        fig, ax = plt.subplots(1, 1, figsize=(10, 6))
        
        modules = ['Object Detection', 'Attribute Prediction', 'Relationship Prediction']
        precision_scores = [
            metrics.get('object_precision', 0.0),
            metrics.get('attribute_precision', 0.0),
            metrics.get('relationship_precision', 0.0)
        ]
        recall_scores = [
            metrics.get('object_recall', 0.0),
            metrics.get('attribute_recall', 0.0),
            metrics.get('relationship_recall', 0.0)
        ]
        f1_scores = [
            metrics.get('object_f1', 0.0),
            metrics.get('attribute_f1', 0.0),
            metrics.get('relationship_f1', 0.0)
        ]
        
        x = np.arange(len(modules))
        width = 0.25
        
        ax.bar(x - width, precision_scores, width, label='Precision', alpha=0.8)
        ax.bar(x, recall_scores, width, label='Recall', alpha=0.8)
        ax.bar(x + width, f1_scores, width, label='F1-Score', alpha=0.8)
        
        ax.set_xlabel('模块')
        ax.set_ylabel('分数')
        ax.set_title('各模块性能对比')
        ax.set_xticks(x)
        ax.set_xticklabels(modules)
        ax.legend()
        ax.set_ylim(0, 1)
        
        # 添加数值标签
        for i, (p, r, f) in enumerate(zip(precision_scores, recall_scores, f1_scores)):
            ax.text(i - width, p + 0.01, f'{p:.3f}', ha='center', va='bottom')
            ax.text(i, r + 0.01, f'{r:.3f}', ha='center', va='bottom')
            ax.text(i + width, f + 0.01, f'{f:.3f}', ha='center', va='bottom')
            
        plt.tight_layout()
        plt.savefig(output_dir / 'module_performance.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 2. mAP对比
        fig, ax = plt.subplots(1, 1, figsize=(8, 6))
        
        map_scores = [
            metrics.get('object_map', 0.0),
            metrics.get('attribute_map', 0.0),
            metrics.get('relationship_map', 0.0),
            metrics.get('mean_ap', 0.0)
        ]
        map_labels = ['Object mAP', 'Attribute mAP', 'Relationship mAP', 'Overall mAP']
        
        bars = ax.bar(map_labels, map_scores, alpha=0.8, 
                     color=['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728'])
        
        ax.set_ylabel('mAP分数')
        ax.set_title('平均精度(mAP)对比')
        ax.set_ylim(0, 1)
        
        # 添加数值标签
        for bar, score in zip(bars, map_scores):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 0.01,
                   f'{score:.3f}', ha='center', va='bottom')
                   
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig(output_dir / 'map_comparison.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 3. 场景图整体指标
        fig, ax = plt.subplots(1, 1, figsize=(6, 6))
        
        sg_metrics = [
            metrics.get('scene_graph_accuracy', 0.0),
            metrics.get('triplet_recall', 0.0)
        ]
        sg_labels = ['Graph Accuracy', 'Triplet Recall']
        
        bars = ax.bar(sg_labels, sg_metrics, alpha=0.8, color=['#9467bd', '#8c564b'])
        
        ax.set_ylabel('分数')
        ax.set_title('场景图整体指标')
        ax.set_ylim(0, 1)
        
        # 添加数值标签
        for bar, score in zip(bars, sg_metrics):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 0.01,
                   f'{score:.3f}', ha='center', va='bottom')
                   
        plt.tight_layout()
        plt.savefig(output_dir / 'scene_graph_metrics.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        self.logger.info("可视化图表已生成")
        
    def evaluate_single_image(self, image_path: str) -> Dict:
        """评估单张图像
        
        Args:
            image_path: 图像路径
            
        Returns:
            预测的场景图
        """
        from PIL import Image
        import torchvision.transforms as transforms
        
        # 加载和预处理图像
        image = Image.open(image_path).convert('RGB')
        
        transform = transforms.Compose([
            transforms.Resize((self.config['model']['image_size'], self.config['model']['image_size'])),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        
        image_tensor = transform(image).unsqueeze(0).to(self.device)
        
        # 预测
        with torch.no_grad():
            predictions = self.model(image_tensor)
            
        # 解析场景图
        pred_dict = {
            k: v.cpu() if isinstance(v, torch.Tensor) else v
            for k, v in predictions.items()
        }
        
        scene_graph = self.metrics._parse_scene_graph(pred_dict)
        readable_sg = self._convert_to_readable(scene_graph)
        
        return readable_sg
        
    def benchmark_inference_speed(self, num_samples: int = 100) -> Dict[str, float]:
        """基准测试推理速度
        
        Args:
            num_samples: 测试样本数量
            
        Returns:
            速度统计
        """
        self.logger.info(f"开始推理速度基准测试，样本数: {num_samples}")
        
        # 创建随机输入
        image_size = self.config['model']['image_size']
        dummy_input = torch.randn(1, 3, image_size, image_size).to(self.device)
        
        # 预热
        for _ in range(10):
            with torch.no_grad():
                _ = self.model(dummy_input)
                
        # 测试推理时间
        times = []
        
        for _ in tqdm(range(num_samples), desc="推理速度测试"):
            start_time = time.time()
            
            with torch.no_grad():
                _ = self.model(dummy_input)
                
            if torch.cuda.is_available():
                torch.cuda.synchronize()
                
            end_time = time.time()
            times.append(end_time - start_time)
            
        # 计算统计信息
        times = np.array(times)
        
        speed_stats = {
            'mean_time': float(np.mean(times)),
            'std_time': float(np.std(times)),
            'min_time': float(np.min(times)),
            'max_time': float(np.max(times)),
            'fps': float(1.0 / np.mean(times)),
            'samples_per_second': float(num_samples / np.sum(times))
        }
        
        self.logger.info(f"推理速度统计:")
        self.logger.info(f"  平均时间: {speed_stats['mean_time']:.4f}s")
        self.logger.info(f"  标准差: {speed_stats['std_time']:.4f}s")
        self.logger.info(f"  FPS: {speed_stats['fps']:.2f}")
        
        return speed_stats


def main():
    parser = argparse.ArgumentParser(description='评估场景图生成模型')
    parser.add_argument('--config', type=str, required=True, help='配置文件路径')
    parser.add_argument('--checkpoint', type=str, required=True, help='模型检查点路径')
    parser.add_argument('--split', type=str, default='test', choices=['train', 'val', 'test'], help='评估数据集分割')
    parser.add_argument('--image', type=str, help='单张图像路径（可选）')
    parser.add_argument('--benchmark', action='store_true', help='运行推理速度基准测试')
    parser.add_argument('--gpu', type=int, help='使用的GPU ID')
    
    args = parser.parse_args()
    
    # 设置GPU
    if args.gpu is not None:
        os.environ['CUDA_VISIBLE_DEVICES'] = str(args.gpu)
        
    # 加载配置
    with open(args.config, 'r', encoding='utf-8') as f:
        config = json.load(f)
        
    # 创建评估器
    evaluator = Evaluator(config, args.checkpoint)
    
    # 评估数据集
    if not args.image:
        metrics = evaluator.evaluate_dataset(args.split)
        print("\n=== 评估完成 ===")
        print(f"平均mAP: {metrics['mean_ap']:.4f}")
        
    # 评估单张图像
    if args.image:
        scene_graph = evaluator.evaluate_single_image(args.image)
        print("\n=== 单张图像预测结果 ===")
        print(json.dumps(scene_graph, indent=2, ensure_ascii=False))
        
    # 推理速度基准测试
    if args.benchmark:
        speed_stats = evaluator.benchmark_inference_speed()
        print("\n=== 推理速度基准测试 ===")
        print(f"平均FPS: {speed_stats['fps']:.2f}")


if __name__ == '__main__':
    main()