import os
import json
import yaml
import argparse
import logging
from pathlib import Path
from typing import Dict, List, Optional
import time
import signal
from contextlib import contextmanager
# import wandb  # 已移除wandb依赖

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.cuda.amp import GradScaler
from torch.amp import autocast
from tqdm import tqdm
import numpy as np

from src.data.dataset import VisualGenomeDataset, create_dataloader, HuggingFaceVisualGenomeDataset, create_huggingface_dataloader
from src.models.scene_graph_hnet import SceneGraphHNet
from src.models.losses import SceneGraphLoss, compute_class_weights
from src.evaluation.metrics import SceneGraphMetrics
from src.utils.checkpoint import save_checkpoint, load_checkpoint
from src.utils.logger import setup_logger
from src.utils.visualization import visualize_scene_graph


class BatchTimeoutError(Exception):
    """Batch处理超时异常"""
    pass


class BatchMonitor:
    """批次监控器，用于记录各个操作阶段的时间并检测超时"""
    
    def __init__(self, logger):
        self.logger = logger
        self.checkpoints = {}
        
    def checkpoint(self, name):
        """记录检查点时间"""
        self.checkpoints[name] = time.time()
        self.logger.debug(f"Checkpoint '{name}' at {self.checkpoints[name]}")
        
    def check_timeout(self, name, timeout=30):
        """检查某个操作是否超时"""
        if name in self.checkpoints:
            elapsed = time.time() - self.checkpoints[name]
            if elapsed > timeout:
                self.logger.warning(f"操作 '{name}' 已运行 {elapsed:.2f} 秒")
                return True
        return False
        
    def get_elapsed(self, name):
        """获取某个操作的耗时"""
        if name in self.checkpoints:
            return time.time() - self.checkpoints[name]
        return 0.0


@contextmanager
def timeout_context(seconds):
    """超时上下文管理器"""
    def timeout_handler(signum, frame):
        import traceback
        import logging
        logger = logging.getLogger("timeout")
        logger.warning("SIGALRM触发，当前堆栈如下：")
        traceback.print_stack(frame)
        for handler in logger.handlers:
            handler.flush()
        raise BatchTimeoutError(f"Batch处理超时 ({seconds}秒)")
    # 设置信号处理器
    old_handler = signal.signal(signal.SIGALRM, timeout_handler)
    # 新增调试：注册后立即写入信号处理器状态
    with open("/tmp/sig_debug.log", "a") as f:
        f.write(f"timeout_context注册后SIGALRM信号处理器: {signal.getsignal(signal.SIGALRM)}\n")
    signal.alarm(seconds)
    try:
        yield
    finally:
        # 恢复原来的信号处理器
        signal.alarm(0)
        signal.signal(signal.SIGALRM, old_handler)


class Trainer:
    """场景图生成训练器"""
    
    def __init__(self, config: Dict, resume_from: Optional[str] = None):
        self.config = config
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # 设置日志
        self.logger = setup_logger('trainer', config['logging']['log_dir'])
        self.logger.info(f"使用设备: {self.device}")
        with open("/tmp/sig_debug.log", "a") as f:
            f.write(f"主进程PID: {os.getpid()}\n")
            import threading
            f.write(f"主线程ID: {threading.get_ident()}\n")
            import signal
            f.write(f"SIGALRM信号处理器: {signal.getsignal(signal.SIGALRM)}\n")
        self.logger.info(f"使用设备: {self.device}")
        
        # 创建输出目录
        self.output_dir = Path(config['training']['output_dir'])
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # 初始化日志文件
        self.log_file = self.output_dir / 'training_log.csv'
        if not self.log_file.exists():
            with open(self.log_file, 'w') as f:
                f.write('epoch,step,train_loss,val_loss,val_mAP\n')
        
        # 初始化模型
        self.model = SceneGraphHNet(config).to(self.device)
        self.logger.info(f"模型参数数量: {sum(p.numel() for p in self.model.parameters()):,}")
        
        # 初始化数据集
        self._setup_datasets()
        
        # 初始化损失函数
        self.criterion = SceneGraphLoss(config).to(self.device)
        
        # 计算类别权重
        if config['training']['use_class_weights']:
            self._compute_class_weights()
            
        # 初始化优化器和调度器
        self._setup_optimizer()
        
        # 初始化评估指标
        self.metrics = SceneGraphMetrics(config)
        
        # 混合精度训练
        self.use_amp = config['training']['use_amp']
        if self.use_amp:
            self.scaler = GradScaler()
            
        # 训练状态
        self.epoch = 0
        self.global_step = 0
        self.best_metric = 0.0
        
        # 恢复训练
        if resume_from:
            self._resume_training(resume_from)
            
        # wandb已移除
            
    def _setup_datasets(self):
        """设置数据集"""
        data_config = self.config['data']
        
        # 检查是否使用 Hugging Face 数据集
        use_huggingface = data_config.get('use_huggingface', False)
        use_visual_genome_driver = data_config.get('use_visual_genome_driver', False)
        
        if use_huggingface:
            self.logger.info("使用 Hugging Face Visual Genome 数据集")
            
            # 训练集
            self.train_loader = create_huggingface_dataloader(
                split='train',
                batch_size=self.config['training']['batch_size'],
                max_objects=self.config['model']['max_objects_per_image'],
                num_workers=0,
                pin_memory=data_config.get('pin_memory', True),
                shuffle=True,
                max_samples=data_config.get('max_samples', None),

            )
            
            # 验证集
            self.val_loader = create_huggingface_dataloader(
                split='validation',
                batch_size=self.config['training'].get('eval_batch_size', self.config['training']['batch_size']),
                max_objects=self.config['model']['max_objects_per_image'],
                num_workers=0,
                pin_memory=data_config.get('pin_memory', True),
                shuffle=False,
                max_samples=data_config.get('max_samples', None),
                )
            
            # 创建临时数据集实例来获取词汇表信息
            temp_dataset = HuggingFaceVisualGenomeDataset(
                split='train',
                max_objects=self.config['model']['max_objects_per_image'],
                max_samples=10  # 只加载少量样本来获取词汇表
            )
            
            # 设置词汇表信息到配置中
            self.config['model']['num_object_classes'] = len(temp_dataset.object_classes)
            self.config['model']['num_predicate_classes'] = len(temp_dataset.predicate_classes)
            self.config['model']['num_attribute_classes'] = len(temp_dataset.attribute_classes)
            
            self.logger.info(f"对象类别数: {len(temp_dataset.object_classes)}")
            self.logger.info(f"关系类别数: {len(temp_dataset.predicate_classes)}")
            self.logger.info(f"属性类别数: {len(temp_dataset.attribute_classes)}")
            self.logger.info(f"训练数据加载器大小: {len(self.train_loader)}")
            self.logger.info(f"验证数据加载器大小: {len(self.val_loader)}")
            self.logger.info(f"训练数据加载器大小: {len(self.train_loader)}")
            self.logger.info(f"验证数据加载器大小: {len(self.val_loader)}")
            
        elif use_visual_genome_driver:
            self.logger.info("使用 Visual Genome Python Driver 数据集")
            
            # 训练集
            self.train_loader = create_huggingface_dataloader(
                split='train',
                batch_size=self.config['training']['batch_size'],
                max_objects=self.config['model']['max_objects_per_image'],
                num_workers=data_config['num_workers'],
                pin_memory=True,
                shuffle=True,
                max_samples=data_config.get('max_samples', None)
            )
            
            # 验证集
            self.val_loader = create_huggingface_dataloader(
                split='validation',
                batch_size=self.config['training'].get('eval_batch_size', self.config['training']['batch_size']),
                max_objects=self.config['model']['max_objects_per_image'],
                num_workers=data_config['num_workers'],
                pin_memory=True,
                shuffle=False,
                max_samples=data_config.get('max_samples', None)
            )
            
            # 创建临时数据集实例来获取词汇表信息
            temp_dataset = HuggingFaceVisualGenomeDataset(
                split='train',
                max_objects=self.config['model']['max_objects_per_image'],
                max_samples=10  # 只加载少量样本来获取词汇表
            )
            
            # 设置词汇表信息到配置中
            self.config['model']['num_object_classes'] = len(temp_dataset.object_classes)
            self.config['model']['num_predicate_classes'] = len(temp_dataset.predicate_classes)
            self.config['model']['num_attribute_classes'] = len(temp_dataset.attribute_classes)
            
            self.logger.info(f"对象类别数: {len(temp_dataset.object_classes)}")
            self.logger.info(f"关系类别数: {len(temp_dataset.predicate_classes)}")
            self.logger.info(f"属性类别数: {len(temp_dataset.attribute_classes)}")
            
        else:
            self.logger.info("使用本地 Visual Genome 数据集")
            
            # 训练集
            self.train_dataset = VisualGenomeDataset(
                data_root=data_config['data_dir'],
                split='train'
            )
            
            self.train_loader = create_dataloader(
                data_root=data_config['data_dir'],
                split='train',
                batch_size=self.config['training']['batch_size'],
                num_workers=data_config['num_workers'],
                pin_memory=True,
                shuffle=True
            )
            
            # 验证集
            self.val_dataset = VisualGenomeDataset(
                data_root=data_config['data_dir'],
                split='val'
            )
            
            self.val_loader = create_dataloader(
                data_root=data_config['data_dir'],
                split='val',
                batch_size=self.config['training'].get('eval_batch_size', self.config['training']['batch_size']),
                num_workers=data_config['num_workers'],
                pin_memory=True,
                shuffle=False
            )
            
            self.logger.info(f"训练集大小: {len(self.train_dataset)}")
            self.logger.info(f"验证集大小: {len(self.val_dataset)}")
            self.logger.info(f"训练数据加载器大小: {len(self.train_loader)}")
            self.logger.info(f"验证数据加载器大小: {len(self.val_loader)}")
        
    def _compute_class_weights(self):
        """计算类别权重"""
        self.logger.info("计算类别权重...")
        weights = compute_class_weights(self.train_dataset, self.config)
        
        self.criterion.update_class_weights(
            weights['object_weights'].to(self.device),
            weights['predicate_weights'].to(self.device),
            weights['attribute_weights'].to(self.device)
        )
        
        self.logger.info("类别权重计算完成")
        
    def _setup_optimizer(self):
        """设置优化器和学习率调度器"""
        train_config = self.config['training']
        
        # 优化器
        if train_config['optimizer'] == 'adamw':
            self.optimizer = optim.AdamW(
                self.model.parameters(),
                lr=train_config['learning_rate'],
                weight_decay=train_config['weight_decay'],
                betas=(0.9, 0.999)
            )
        elif train_config['optimizer'] == 'adam':
            self.optimizer = optim.Adam(
                self.model.parameters(),
                lr=train_config['learning_rate'],
                weight_decay=train_config['weight_decay']
            )
        else:
            raise ValueError(f"不支持的优化器: {train_config['optimizer']}")
            
        # 学习率调度器
        if train_config['lr_scheduler'] == 'cosine':
            self.scheduler = optim.lr_scheduler.CosineAnnealingLR(
                self.optimizer,
                T_max=train_config['num_epochs'],
                eta_min=train_config['min_learning_rate']
            )
        elif train_config['lr_scheduler'] == 'step':
            self.scheduler = optim.lr_scheduler.StepLR(
                self.optimizer,
                step_size=train_config['lr_decay_steps'],
                gamma=train_config['lr_decay_factor']
            )
        elif train_config['lr_scheduler'] == 'warmup_cosine':
            from torch.optim.lr_scheduler import LambdaLR
            
            def lr_lambda(step):
                warmup_steps = train_config['warmup_steps']
                total_steps = len(self.train_loader) * train_config['num_epochs']
                
                if step < warmup_steps:
                    return step / warmup_steps
                else:
                    progress = (step - warmup_steps) / (total_steps - warmup_steps)
                    return 0.5 * (1 + np.cos(np.pi * progress))
                    
            self.scheduler = LambdaLR(self.optimizer, lr_lambda)
        elif train_config['lr_scheduler'] == 'reduce_on_plateau':
            self.scheduler = optim.lr_scheduler.ReduceLROnPlateau(
                self.optimizer,
                mode='min',
                factor=train_config.get('lr_decay_factor', 0.1),
                patience=train_config.get('lr_patience', 10)
            )
        else:
            self.scheduler = None
            
    def _resume_training(self, checkpoint_path: str):
        """恢复训练"""
        self.logger.info(f"从检查点恢复训练: {checkpoint_path}")
        
        checkpoint = load_checkpoint(checkpoint_path, self.device)
        
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        
        if self.scheduler and 'scheduler_state_dict' in checkpoint:
            self.scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
            
        if self.use_amp and 'scaler_state_dict' in checkpoint:
            self.scaler.load_state_dict(checkpoint['scaler_state_dict'])
            
        self.epoch = checkpoint['epoch']
        self.global_step = checkpoint['global_step']
        self.best_metric = checkpoint.get('best_metric', 0.0)
        
        self.logger.info(f"恢复到epoch {self.epoch}, step {self.global_step}")
        
    def train_epoch(self) -> Dict[str, float]:
        """训练一个epoch"""
        self.model.train()
        
        total_loss = 0.0
        loss_components = {
            'object_detection': 0.0,
            'attribute': 0.0,
            'relationship': 0.0,
            'boundary_regularization': 0.0
        }
        
        progress_bar = tqdm(
            self.train_loader,
            desc=f"Epoch {self.epoch + 1}/{self.config['training']['num_epochs']}",
            leave=False
        )
        
        # 梯度累积配置
        accumulate_grad_batches = self.config['training'].get('accumulate_grad_batches', 1)
        self.logger.info(f"开始训练epoch {self.epoch + 1}，数据加载器大小: {len(self.train_loader)}，梯度累积步数: {accumulate_grad_batches}")
        
        # 创建批次监控器
        monitor = BatchMonitor(self.logger)
        
        for batch_idx, batch in enumerate(progress_bar):
            try:
                monitor.checkpoint('batch_start')
                
                # 数据移动
                monitor.checkpoint('data_to_device_start')
                images = batch['image'].to(self.device, non_blocking=True)
                scene_graphs = {
                    k: v.to(self.device, non_blocking=True) if isinstance(v, torch.Tensor) else v
                    for k, v in batch['scene_graph'].items()
                }
                torch.cuda.synchronize()  # 确保数据传输完成
                monitor.checkpoint('data_to_device_end')
                
                # 只在累积开始时清零梯度
                if batch_idx % accumulate_grad_batches == 0:
                    self.optimizer.zero_grad()
                
                # 前向传播和损失计算
                monitor.checkpoint('forward_start')
                if self.use_amp:
                    with autocast(device_type='cuda'):
                        predictions = self.model(images)
                        monitor.checkpoint('forward_end')
                        
                        # 损失计算也需要在autocast范围内
                        monitor.checkpoint('loss_start')
                        losses = self.criterion(predictions, scene_graphs)
                        monitor.checkpoint('loss_end')
                else:
                    predictions = self.model(images)
                    monitor.checkpoint('forward_end')
                    
                    # 损失计算
                    monitor.checkpoint('loss_start')
                    losses = self.criterion(predictions, scene_graphs)
                    monitor.checkpoint('loss_end')
                
                # 反向传播
                monitor.checkpoint('backward_start')
                loss = losses['total'] / accumulate_grad_batches
                if self.use_amp:
                    self.scaler.scale(loss).backward()
                else:
                    loss.backward()
                monitor.checkpoint('backward_end')
                
                # 只在累积完成时执行优化器步骤
                if (batch_idx + 1) % accumulate_grad_batches == 0 or (batch_idx + 1) == len(self.train_loader):
                    monitor.checkpoint('optimizer_start')
                    if self.use_amp:
                        # 梯度裁剪
                        if self.config['training']['max_grad_norm'] > 0:
                            self.scaler.unscale_(self.optimizer)
                            torch.nn.utils.clip_grad_norm_(
                                self.model.parameters(),
                                self.config['training']['max_grad_norm']
                            )
                        self.scaler.step(self.optimizer)
                        self.scaler.update()
                    else:
                        # 梯度裁剪
                        if self.config['training']['max_grad_norm'] > 0:
                            torch.nn.utils.clip_grad_norm_(
                                self.model.parameters(),
                                self.config['training']['max_grad_norm']
                            )
                        self.optimizer.step()
                    monitor.checkpoint('optimizer_end')
                
                # 检查各阶段是否超时
                for checkpoint in ['data_to_device_start', 'forward_start', 'loss_start', 'backward_start']:
                    if monitor.check_timeout(checkpoint, timeout=60):
                        raise BatchTimeoutError(f"操作 {checkpoint} 超时")
                
                # 记录各阶段耗时
                data_time = (monitor.checkpoints.get('data_to_device_end', 0) - monitor.checkpoints.get('data_to_device_start', 0)) if 'data_to_device_end' in monitor.checkpoints else 0
                forward_time = (monitor.checkpoints.get('forward_end', 0) - monitor.checkpoints.get('forward_start', 0)) if 'forward_end' in monitor.checkpoints else 0
                loss_time = (monitor.checkpoints.get('loss_end', 0) - monitor.checkpoints.get('loss_start', 0)) if 'loss_end' in monitor.checkpoints else 0
                backward_time = (monitor.checkpoints.get('backward_end', 0) - monitor.checkpoints.get('backward_start', 0)) if 'backward_end' in monitor.checkpoints else 0
                
                total_time = monitor.get_elapsed('batch_start')
                self.logger.info(f"Batch {batch_idx + 1} - 总耗时: {total_time:.2f}s, 数据: {data_time:.2f}s, 前向: {forward_time:.2f}s, 损失: {loss_time:.2f}s, 反向: {backward_time:.2f}s")
                        
            except BatchTimeoutError as e:
                self.logger.warning(f"Batch {batch_idx + 1} 超时，跳过: {e}")
                self.logger.error(f"检查点信息: {monitor.checkpoints}")
                # 清理可能的梯度
                self.optimizer.zero_grad()
                # 设置一个默认损失值用于显示
                loss = torch.tensor(0.0, device=self.device)
                losses = {'total': loss, 'object_detection': loss, 'attribute': loss, 'relationship': loss, 'boundary_regularization': loss}
                continue
            except Exception as e:
                self.logger.error(f"Batch {batch_idx + 1} 处理出错: {e}")
                self.logger.error(f"检查点信息: {monitor.checkpoints}")
                # 清理可能的梯度
                self.optimizer.zero_grad()
                # 设置一个默认损失值用于显示
                loss = torch.tensor(0.0, device=self.device)
                losses = {'total': loss, 'object_detection': loss, 'attribute': loss, 'relationship': loss, 'boundary_regularization': loss}
                continue
                
            # 只在实际执行优化器步骤时更新学习率和全局步数
            if (batch_idx + 1) % accumulate_grad_batches == 0 or (batch_idx + 1) == len(self.train_loader):
                if self.scheduler and self.config['training']['lr_scheduler'] == 'warmup_cosine':
                    self.scheduler.step()
                self.global_step += 1
                
            # 累计损失（注意这里要乘回accumulate_grad_batches因为前面除过了）
            total_loss += loss.item() * accumulate_grad_batches
            for key in loss_components:
                if key in losses:
                    loss_components[key] += losses[key].item()
            
            # 更新进度条
            progress_bar.set_postfix({
                'loss': f"{loss.item():.4f}",
                'lr': f"{self.optimizer.param_groups[0]['lr']:.2e}"
            })
            
            # 记录日志（只在实际执行优化器步骤时记录）
            if (batch_idx + 1) % accumulate_grad_batches == 0 or (batch_idx + 1) == len(self.train_loader):
                if self.global_step % self.config['logging']['log_interval'] == 0:
                    self._log_training_step(losses)
                
        # 计算平均损失
        avg_loss = total_loss / len(self.train_loader)
        for key in loss_components:
            loss_components[key] /= len(self.train_loader)
            
        return {'total': avg_loss, **loss_components}
        
    def validate(self) -> Dict[str, float]:
        """验证模型"""
        self.model.eval()
        
        total_loss = 0.0
        all_predictions = []
        all_targets = []
        
        with torch.no_grad():
            for batch in tqdm(self.val_loader, desc="验证中", leave=False):
                images = batch['image'].to(self.device)
                scene_graphs = {
                    k: v.to(self.device) if isinstance(v, torch.Tensor) else v
                    for k, v in batch['scene_graph'].items()
                }
                
                # 前向传播和损失计算
                if self.use_amp:
                    with autocast(device_type='cuda'):
                        predictions = self.model(images)
                        losses = self.criterion(predictions, scene_graphs)
                else:
                    predictions = self.model(images)
                    losses = self.criterion(predictions, scene_graphs)
                    
                total_loss += losses['total'].item()
                
                # 收集预测和目标用于评估
                # 将SceneGraphOutput转换为字典格式
                pred_dict = {
                    'object_logits': predictions.object_logits.cpu(),
                    'attribute_logits': predictions.attribute_logits.cpu(),
                    'relationship_logits': predictions.relationship_logits.cpu(),
                    'object_existence': predictions.object_existence.cpu(),
                    'boundary_predictions': predictions.boundary_predictions
                }
                all_predictions.append(pred_dict)
                all_targets.append({
                    k: v.cpu() if isinstance(v, torch.Tensor) else v
                    for k, v in scene_graphs.items()
                })
                
        # 计算评估指标
        metrics = self.metrics.compute_metrics(all_predictions, all_targets)
        metrics['val_loss'] = total_loss / len(self.val_loader)
        
        return metrics
        
    def _log_training_step(self, losses: Dict[str, torch.Tensor]):
        """记录训练步骤"""
        log_dict = {
            'train/total_loss': losses['total'].item(),
            'train/object_detection_loss': losses['object_detection'].item(),
            'train/attribute_loss': losses['attribute'].item(),
            'train/relationship_loss': losses['relationship'].item(),
            'train/boundary_regularization_loss': losses['boundary_regularization'].item(),
            'train/learning_rate': self.optimizer.param_groups[0]['lr'],
            'train/epoch': self.epoch,
            'train/step': self.global_step
        }
        
        self.log_metrics(log_dict)
            
    def _log_epoch(self, train_metrics: Dict[str, float], val_metrics: Dict[str, float]):
        """记录epoch结果"""
        log_dict = {
            f'epoch/train_{k}': v for k, v in train_metrics.items()
        }
        log_dict.update({
            f'epoch/val_{k}': v for k, v in val_metrics.items()
        })
        log_dict['epoch/epoch'] = self.epoch
        
        self.log_metrics(log_dict)
            
        # 打印日志
        self.logger.info(
            f"Epoch {self.epoch + 1}: "
            f"Train Loss: {train_metrics['total']:.4f}, "
            f"Val Loss: {val_metrics['val_loss']:.4f}, "
            f"Val mAP: {val_metrics.get('mean_ap', 0.0):.4f}"
        )
        
    def save_checkpoint(self, is_best: bool = False):
        """保存检查点"""
        checkpoint = {
            'epoch': self.epoch,
            'global_step': self.global_step,
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'best_metric': self.best_metric,
            'config': self.config
        }
        
        if self.scheduler:
            checkpoint['scheduler_state_dict'] = self.scheduler.state_dict()
            
        if self.use_amp:
            checkpoint['scaler_state_dict'] = self.scaler.state_dict()
            
        # 保存最新检查点
        save_checkpoint(
            checkpoint,
            self.output_dir / 'checkpoint_latest.pth'
        )
        
        # 保存最佳检查点
        if is_best:
            save_checkpoint(
                checkpoint,
                self.output_dir / 'checkpoint_best.pth'
            )
            
        # 定期保存检查点
        save_interval = self.config['training'].get('save_interval') or self.config['training'].get('save_every_n_epochs')
        if save_interval and (self.epoch + 1) % save_interval == 0:
            save_checkpoint(
                checkpoint,
                self.output_dir / f'checkpoint_epoch_{self.epoch + 1}.pth'
            )
            
    def log_metrics(self, metrics: Dict):
        """将指标记录到CSV文件"""
        if 'epoch/epoch' in metrics:
            epoch = metrics['epoch/epoch']
            step = self.global_step
            train_loss = metrics.get('epoch/train_total', 0.0)
            val_loss = metrics.get('epoch/val_val_loss', 0.0)
            val_mAP = metrics.get('epoch/val_mean_ap', 0.0)

            with open(self.log_file, 'a') as f:
                f.write(f'{epoch},{step},{train_loss},{val_loss},{val_mAP}\n')

    def visualize_results(self, predictions: List[Dict], targets: List[Dict], dataset, num_samples: int = 5):
        """可视化一些验证结果"""
        self.logger.info(f"可视化 {num_samples} 个样本...")
        output_dir = self.output_dir / f'visualizations_epoch_{self.epoch + 1}'
        output_dir.mkdir(exist_ok=True)

        for i in range(min(num_samples, len(predictions))):
            try:
                pred_graph = predictions[i]
                target_graph = targets[i]
                image_info = dataset.get_image_info(i) # 假设dataset有这个方法

                visualize_scene_graph(
                    image_path=image_info['path'],
                    pred_scene_graph=pred_graph,
                    true_scene_graph=target_graph,
                    object_classes=dataset.object_classes,
                    predicate_classes=dataset.predicate_classes,
                    attribute_classes=dataset.attribute_classes,
                    output_path=output_dir / f'sample_{i}.png'
                )
            except Exception as e:
                self.logger.error(f"可视化样本 {i} 时出错: {e}")

    def train(self):
        """主训练循环"""
        self.logger.info("开始训练...")
        
        for epoch in range(self.epoch, self.config['training']['num_epochs']):
            self.epoch = epoch
            
            # 训练一个epoch
            train_metrics = self.train_epoch()
            
            # 验证
            val_metrics = self.validate()
            
            # 更新学习率
            if self.scheduler:
                if self.config['training']['lr_scheduler'] == 'reduce_on_plateau':
                    val_loss = val_metrics.get('val_loss', 0.0)
                    # 确保 val_loss 是浮点数
                    if not isinstance(val_loss, (int, float)):
                        self.logger.warning(f"val_loss 不是数字，而是 {type(val_loss)}: {val_loss}。使用0.0作为默认值。")
                        val_loss = 0.0
                    self.scheduler.step(val_loss)
                elif self.config['training']['lr_scheduler'] != 'warmup_cosine':
                    self.scheduler.step()
                
            # 记录日志
            self._log_epoch(train_metrics, val_metrics)
            
            # 检查是否是最佳模型
            current_metric = val_metrics.get('mean_ap', val_metrics.get('val_loss', 0.0))
            is_best = current_metric > self.best_metric
            if is_best:
                self.best_metric = current_metric
                
            # 保存检查点
            self.save_checkpoint(is_best)
            
        self.logger.info("训练完成!")
        
        # 可视化一些结果
        # self.visualize_results(all_predictions, all_targets, self.val_loader.dataset)


def main():
    parser = argparse.ArgumentParser(description='训练场景图生成模型')
    parser.add_argument('--config', type=str, required=True, help='配置文件路径')
    parser.add_argument('--resume', type=str, help='恢复训练的检查点路径')
    parser.add_argument('--gpu', type=int, help='使用的GPU ID')
    
    args = parser.parse_args()
    
    # 设置GPU
    if args.gpu is not None:
        os.environ['CUDA_VISIBLE_DEVICES'] = str(args.gpu)
        
    # 加载配置
    with open(args.config, 'r', encoding='utf-8') as f:
        if args.config.endswith('.yaml') or args.config.endswith('.yml'):
            config = yaml.safe_load(f)
        else:
            config = json.load(f)
        
    # 创建训练器并开始训练
    trainer = Trainer(config, resume_from=args.resume)
    trainer.train()


if __name__ == '__main__':
    main()