import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
import sys
import os

# 添加父目录到路径以导入hnet模块
sys.path.append(os.path.join(os.path.dirname(__file__), '../../../'))

from hnet.models.hnet import HNet, HNetState
from hnet.models.config_hnet import HNetConfig, AttnConfig, SSMConfig
from hnet.modules.dc import RoutingModuleOutput
from einops import rearrange, repeat


@dataclass
class SceneGraphOutput:
    """场景图生成输出"""
    object_logits: torch.Tensor  # (B, max_objects, num_object_classes)
    attribute_logits: torch.Tensor  # (B, max_objects, num_attribute_classes)
    relationship_logits: torch.Tensor  # (B, max_objects, max_objects, num_predicate_classes)
    object_existence: torch.Tensor  # (B, max_objects) - 对象是否存在的概率
    boundary_predictions: List[RoutingModuleOutput]
    inference_params: Optional[HNetState] = None


class MinimalDynamicChunking(nn.Module):
    """极简版本的动态分块，只做必要的计算"""
    
    def __init__(self, embed_dim: int):
        super().__init__()
        self.embed_dim = embed_dim
        
        # 只用一个1x1卷积做内容感知
        self.content_predictor = nn.Conv2d(embed_dim, 1, 1)  # 最简单的预测器
        self.sigmoid = nn.Sigmoid()
    
    def forward(self, feature_map):
        # 直接预测内容重要性，不做复杂的边界检测
        content_importance = self.sigmoid(self.content_predictor(feature_map))  # (B, 1, H, W)
        
        # 直接应用，不做topk或其他复杂操作
        weighted_features = feature_map * content_importance
        
        return weighted_features


class SoftDynamicChunking(nn.Module):
    """使用软边界而不是硬边界"""
    
    def __init__(self, embed_dim: int, boundary_threshold: float = 0.8, max_boundary_ratio: float = 0.3):
        super().__init__()
        self.embed_dim = embed_dim
        self.boundary_threshold = boundary_threshold  # 边界预测阈值，提高以减少边界数量
        self.max_boundary_ratio = max_boundary_ratio  # 最大边界比例，限制边界数量
        
        # 简化的边界预测器，减少计算复杂度
        self.boundary_predictor = nn.Sequential(
            nn.Conv2d(embed_dim, embed_dim // 4, 3, padding=1),  # 减少中间层维度
            nn.BatchNorm2d(embed_dim // 4),
            nn.ReLU(),
            nn.Conv2d(embed_dim // 4, 1, 1),  # 输出软边界概率
            nn.Sigmoid()
        )
     
    def forward(self, feature_map):
        # 暴力替换为恒等映射，直接返回输入特征
        return feature_map


class AdaptiveChunkMerging(nn.Module):
    """自适应分块合并模块"""
    def __init__(self, hidden_dim):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.merge_predictor = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()
        )
    
    def forward(self, chunks, chunk_positions):
        """预测哪些相邻chunks应该合并"""
        if len(chunks) <= 1:
            return chunks
        
        # 简化实现：直接返回原始chunks，避免复杂的合并逻辑
        # 在实际应用中，可以根据需要实现更复杂的合并策略
        return chunks
    
    def _merge_chunks(self, chunks, merge_scores):
        """基于合并分数合并chunks"""
        merged = []
        i = 0
        
        while i < len(chunks):
            current_chunk = chunks[i]
            
            # 检查是否应该与下一个chunk合并
            if i < len(merge_scores) and merge_scores[i].mean().item() > 0.5:
                # 合并当前chunk和下一个chunk
                next_chunk = chunks[i + 1]
                merged_chunk = (current_chunk + next_chunk) / 2
                merged.append(merged_chunk)
                i += 2  # 跳过下一个chunk
            else:
                merged.append(current_chunk)
                i += 1
        
        return merged


class DynamicImageEmbedding(nn.Module):
    """动态图像嵌入层，支持多尺度特征提取和内容感知分块"""
    
    def __init__(
        self,
        image_size: Tuple[int, int] = (224, 224),
        base_patch_size: Tuple[int, int] = (16, 16),
        in_channels: int = 3,
        embed_dim: int = 768,
        num_scales: int = 1,
        boundary_threshold: float = 0.8,
        max_boundary_ratio: float = 0.2,
        use_minimal_chunking: bool = True
    ):
        super().__init__()
        self.image_size = image_size
        self.base_patch_size = base_patch_size
        self.embed_dim = embed_dim
        self.num_scales = num_scales
        
        # 多尺度卷积层用于特征提取
        self.multi_scale_convs = nn.ModuleList()
        for i in range(num_scales):
            scale_factor = 2 ** i
            kernel_size = (base_patch_size[0] // scale_factor, base_patch_size[1] // scale_factor)
            stride = kernel_size
            
            conv = nn.Conv2d(
                in_channels, embed_dim // num_scales,
                kernel_size=kernel_size,
                stride=stride,
                padding=0
            )
            self.multi_scale_convs.append(conv)
        
        # 动态分块模块，根据参数选择实现
        self.use_minimal_chunking = use_minimal_chunking
        if use_minimal_chunking:
            self.dynamic_chunking = MinimalDynamicChunking(embed_dim)
        else:
            self.dynamic_chunking = SoftDynamicChunking(embed_dim, boundary_threshold, max_boundary_ratio)
        
        # 自适应分块合并模块
        self.chunk_merging = AdaptiveChunkMerging(embed_dim)
        
        # 特征融合层（用于多尺度特征融合）
        self.feature_fusion = nn.Sequential(
            nn.Conv2d(embed_dim, embed_dim, 1),
            nn.BatchNorm2d(embed_dim),
            nn.GELU(),
            nn.Dropout2d(0.1)
        )
        
        # 最终特征处理层
        self.final_projection = nn.Sequential(
            nn.Linear(embed_dim, embed_dim),
            nn.LayerNorm(embed_dim),
            nn.GELU(),
            nn.Dropout(0.1)
        )
        
        # 内容感知分块预测器
        self.chunk_predictor = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.ReLU(),
            nn.Linear(embed_dim // 2, 1),
            nn.Sigmoid()
        )
        
        # 位置编码生成器（动态）
        self.pos_encoder = nn.Sequential(
            nn.Linear(2, embed_dim // 4),  # 2D位置坐标
            nn.ReLU(),
            nn.Linear(embed_dim // 4, embed_dim)
        )
        
        # 全局上下文token
        self.global_token = nn.Parameter(torch.randn(1, 1, embed_dim) * 0.02)
        
    def _generate_position_embeddings(self, features: torch.Tensor, positions: torch.Tensor) -> torch.Tensor:
        """生成动态位置编码"""
        # positions: (B, N, 2) - 归一化的2D坐标
        pos_emb = self.pos_encoder(positions)
        return pos_emb
        
    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """前向传播
        
        Args:
            x: (B, C, H, W) 输入图像
            
        Returns:
            features: (B, N, embed_dim) 动态特征序列
            chunk_scores: (B, N) 分块边界分数
        """
        B, C, H, W = x.shape
        
        # 真正的多尺度特征提取和融合
        multi_scale_features = []
        h_base, w_base = None, None
        
        for i, conv in enumerate(self.multi_scale_convs):
            feat = conv(x)
            if i == 0:
                _, _, h_base, w_base = feat.shape
            # 对齐空间分辨率
            if i > 0:
                feat = F.interpolate(feat, size=(h_base, w_base), mode='bilinear', align_corners=False)
            multi_scale_features.append(feat)
        
        # 融合多尺度特征
        fused_features = torch.cat(multi_scale_features, dim=1)  # (B, embed_dim, H', W')
        fused_features = self.feature_fusion(fused_features)
        
        # 应用动态分块
        chunked_features = self.dynamic_chunking(fused_features)
        
        # 展平并转置
        features = chunked_features.flatten(2).transpose(1, 2)  # (B, H'*W', embed_dim)
        
        # 生成位置坐标
        y_coords = torch.linspace(0, 1, h_base, device=x.device)
        x_coords = torch.linspace(0, 1, w_base, device=x.device)
        yy, xx = torch.meshgrid(y_coords, x_coords, indexing='ij')
        positions = torch.stack([xx.flatten(), yy.flatten()], dim=-1)  # (H'*W', 2)
        positions = positions.unsqueeze(0).expand(B, -1, -1)  # (B, H'*W', 2)
        
        # 简化自适应分块合并，避免复杂的维度操作
        # 直接跳过分块合并步骤，保持原始特征不变
        # 这样可以避免维度不匹配的问题
        pass  # 暂时跳过分块合并
        
        # 最终特征处理
        # 确保features的形状正确
        if features.dim() != 3:
            # 如果features被意外展平，重新reshape
            features = features.view(B, -1, self.embed_dim)
        features = self.final_projection(features)
        
        # 添加位置编码
        pos_emb = self._generate_position_embeddings(features, positions)
        features = features + pos_emb
        
        # 预测分块边界分数（基于动态分块的结果）
        # 确保features的形状正确
        if features.dim() != 3:
            # 如果features被意外展平，重新reshape
            features = features.view(B, -1, self.embed_dim)
        chunk_scores = self.chunk_predictor(features).squeeze(-1)  # (B, H'*W')
        
        # 添加全局上下文token
        global_tokens = self.global_token.expand(B, -1, -1)
        features = torch.cat([global_tokens, features], dim=1)
        
        # 为全局token添加分块分数（设为1.0，表示总是保留）
        global_chunk_scores = torch.ones(B, 1, device=x.device)
        chunk_scores = torch.cat([global_chunk_scores, chunk_scores], dim=1)
        
        return features, chunk_scores


class SceneGraphDecoder(nn.Module):
    """场景图解码器"""
    
    def __init__(
        self,
        hidden_dim: int,
        num_object_classes: int,
        num_predicate_classes: int,
        num_attribute_classes: int,
        max_objects: int = 100
    ):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_object_classes = num_object_classes
        self.num_predicate_classes = num_predicate_classes
        self.num_attribute_classes = num_attribute_classes
        self.max_objects = max_objects
        
        # Object detection head
        self.object_detector = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, num_object_classes)
        )
        
        # Object existence head
        self.existence_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim // 2, 1)
        )
        
        # Attribute prediction head
        self.attribute_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, num_attribute_classes)
        )
        
        # Relationship prediction head
        self.relationship_head = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, num_predicate_classes)
        )
        
        # Object query embeddings
        self.object_queries = nn.Parameter(
            torch.randn(max_objects, hidden_dim) * 0.02
        )
        
        # Cross attention for object detection
        self.cross_attention = nn.MultiheadAttention(
            embed_dim=hidden_dim,
            num_heads=8,
            dropout=0.1,
            batch_first=True
        )
        
    def forward(self, features: torch.Tensor, boundary_info: Optional[List] = None, chunk_scores: Optional[torch.Tensor] = None) -> Dict[str, torch.Tensor]:
        """前向传播
        
        Args:
            features: (B, seq_len, hidden_dim) 图像特征
            boundary_info: H-Net的边界预测信息
            chunk_scores: (B, seq_len) 分块边界分数
            
        Returns:
            场景图预测结果
        """
        B, seq_len, hidden_dim = features.shape
        
        # 如果有分块分数，使用它们来加权特征
        if chunk_scores is not None:
            # 将分块分数作为注意力权重
            chunk_weights = chunk_scores.unsqueeze(-1)  # (B, seq_len, 1)
            weighted_features = features * chunk_weights
        else:
            weighted_features = features
        
        # Expand object queries for batch
        object_queries = self.object_queries.unsqueeze(0).expand(B, -1, -1)
        
        # Cross attention: object queries attend to weighted image features
        object_features, attention_weights = self.cross_attention(
            query=object_queries,
            key=weighted_features,
            value=weighted_features
        )
        
        # 如果有边界信息，将其融入对象特征
        if boundary_info is not None and len(boundary_info) > 0:
            # 提取边界特征（假设boundary_info包含边界预测）
            boundary_features = self._extract_boundary_features(boundary_info, B, self.hidden_dim)
            if boundary_features is not None:
                # 将边界特征与对象特征融合
                object_features = object_features + boundary_features
        
        # Object classification
        object_logits = self.object_detector(object_features)
        
        # Object existence - 考虑分块分数的影响
        existence_features = object_features
        if chunk_scores is not None:
            # 使用注意力权重来调整存在性预测
            avg_chunk_score = torch.mean(chunk_scores, dim=1, keepdim=True).unsqueeze(-1)  # (B, 1, 1)
            existence_features = existence_features * avg_chunk_score
        
        object_existence = torch.sigmoid(self.existence_head(existence_features).squeeze(-1))
        
        # Attribute prediction
        attribute_logits = self.attribute_head(object_features)
        
        # Relationship prediction with boundary-aware features
        # Create pairwise features for all object pairs
        obj_i = object_features.unsqueeze(2).expand(-1, -1, self.max_objects, -1)
        obj_j = object_features.unsqueeze(1).expand(-1, self.max_objects, -1, -1)
        
        # Concatenate pairwise features
        pairwise_features = torch.cat([obj_i, obj_j], dim=-1)
        
        # 如果有边界信息，为关系预测添加空间上下文
        if boundary_info is not None and chunk_scores is not None:
            # 计算对象对之间的空间关系权重
            spatial_weights = self._compute_spatial_weights(chunk_scores, attention_weights)
            if spatial_weights is not None:
                # 将空间权重应用到关系预测
                pairwise_features = pairwise_features * spatial_weights.unsqueeze(-1)
        
        # Predict relationships
        relationship_logits = self.relationship_head(pairwise_features)
        
        return {
            'object_logits': object_logits,
            'attribute_logits': attribute_logits,
            'relationship_logits': relationship_logits,
            'object_existence': object_existence,
            'attention_weights': attention_weights,
            'chunk_scores': chunk_scores
        }
    
    def _extract_boundary_features(self, boundary_info: List, batch_size: int, hidden_dim: int) -> Optional[torch.Tensor]:
        """从边界信息中提取特征"""
        try:
            if not boundary_info or len(boundary_info) == 0:
                return None
            
            # 假设boundary_info是RoutingModuleOutput的列表
            # 提取边界预测并转换为特征
            boundary_features = []
            for boundary_output in boundary_info:
                if hasattr(boundary_output, 'boundary_mask'):
                    # 将边界mask转换为特征
                    mask = boundary_output.boundary_mask
                    if mask is not None:
                        # 不仅提取mask，还要提取边界位置、强度等信息
                        boundary_positions = self.get_boundary_positions(mask)
                        boundary_strengths = self.get_boundary_strengths(mask)
                        enhanced_features = self.boundary_encoder(boundary_positions, boundary_strengths)
                        boundary_features.append(enhanced_features)
            
            if boundary_features:
                # 拼接所有边界特征
                boundary_tensor = torch.cat(boundary_features, dim=-1)
                # 调整维度以匹配对象查询
                if boundary_tensor.shape[1] != self.max_objects:
                    # 使用线性插值调整序列长度
                    boundary_tensor = F.interpolate(
                        boundary_tensor.transpose(1, 2), 
                        size=self.max_objects, 
                        mode='linear', 
                        align_corners=False
                    ).transpose(1, 2)
                
                # 调整特征维度
                if boundary_tensor.shape[-1] != hidden_dim:
                    boundary_tensor = F.linear(boundary_tensor, 
                                             torch.randn(boundary_tensor.shape[-1], hidden_dim, 
                                                       device=boundary_tensor.device) * 0.02)
                
                return boundary_tensor
            
        except Exception as e:
            # 如果边界特征提取失败，返回None
            return None
        
        return None
    
    def get_boundary_positions(self, boundary_mask: torch.Tensor) -> torch.Tensor:
        """提取边界位置信息"""
        # 简化实现：计算边界的重心位置
        B, H, W = boundary_mask.shape
        
        # 创建坐标网格
        y_coords = torch.arange(H, device=boundary_mask.device).float()
        x_coords = torch.arange(W, device=boundary_mask.device).float()
        yy, xx = torch.meshgrid(y_coords, x_coords, indexing='ij')
        
        # 计算加权重心
        total_weight = boundary_mask.sum(dim=[1, 2], keepdim=True) + 1e-8
        center_y = (boundary_mask * yy.unsqueeze(0)).sum(dim=[1, 2], keepdim=True) / total_weight
        center_x = (boundary_mask * xx.unsqueeze(0)).sum(dim=[1, 2], keepdim=True) / total_weight
        
        # 归一化到[0, 1]
        center_y = center_y / H
        center_x = center_x / W
        
        positions = torch.cat([center_x, center_y], dim=-1)  # (B, 1, 2)
        return positions
    
    def get_boundary_strengths(self, boundary_mask: torch.Tensor) -> torch.Tensor:
        """提取边界强度信息"""
        # 计算边界的平均强度和最大强度
        mean_strength = boundary_mask.mean(dim=[1, 2], keepdim=True)  # (B, 1, 1)
        max_strength = boundary_mask.max(dim=2)[0].max(dim=1, keepdim=True)[0].unsqueeze(-1)  # (B, 1, 1)
        
        strengths = torch.cat([mean_strength, max_strength], dim=-1)  # (B, 1, 2)
        return strengths
    
    def boundary_encoder(self, positions: torch.Tensor, strengths: torch.Tensor) -> torch.Tensor:
        """编码边界位置和强度信息"""
        # 简单的线性编码
        combined = torch.cat([positions, strengths], dim=-1)  # (B, 1, 4)
        
        # 扩展到更高维度
        encoded = F.linear(combined, 
                          torch.randn(4, self.hidden_dim // 4, device=combined.device) * 0.02)
        
        return encoded
    
    def _compute_spatial_weights(self, chunk_scores: torch.Tensor, attention_weights: torch.Tensor) -> Optional[torch.Tensor]:
        """计算基于分块和注意力的空间权重"""
        try:
            B, max_objects, seq_len = attention_weights.shape
            
            # 为每个对象对计算空间相关性
            spatial_weights = torch.zeros(B, max_objects, max_objects, device=chunk_scores.device)
            
            for i in range(max_objects):
                for j in range(max_objects):
                    if i != j:
                        # 计算两个对象注意力分布的相似性
                        attn_i = attention_weights[:, i, :]  # (B, seq_len)
                        attn_j = attention_weights[:, j, :]  # (B, seq_len)
                        
                        # 使用余弦相似度计算空间相关性
                        similarity = F.cosine_similarity(attn_i, attn_j, dim=1)  # (B,)
                        
                        # 结合分块分数
                        chunk_weight = torch.mean(chunk_scores * (attn_i + attn_j) / 2, dim=1)  # (B,)
                        
                        # 组合相似性和分块权重
                        spatial_weights[:, i, j] = similarity * chunk_weight
                    else:
                        spatial_weights[:, i, j] = 1.0  # 自身关系权重为1
            
            return spatial_weights
            
        except Exception as e:
            return None


class SceneGraphHNet(nn.Module):
    """基于H-Net的场景图生成模型"""
    
    def __init__(
        self,
        config: Dict,
        device=None,
        dtype=None
    ):
        super().__init__()
        self.config = config
        model_config = config['model']
        
        # 创建H-Net配置
        attn_cfg = AttnConfig(**model_config['attn_cfg'])
        ssm_cfg = SSMConfig(**model_config['ssm_cfg'])
        
        hnet_config = HNetConfig(
            arch_layout=model_config['arch_layout'],
            d_model=model_config['d_model'],
            d_intermediate=model_config['d_intermediate'],
            vocab_size=model_config['vocab_size'],
            ssm_cfg=ssm_cfg,
            attn_cfg=attn_cfg,
            tie_embeddings=model_config['tie_embeddings']
        )
        
        self.hnet_config = hnet_config
        
        # 动态图像嵌入
        dynamic_chunking_config = model_config.get('dynamic_chunking', {})
        self.patch_embedding = DynamicImageEmbedding(
            image_size=tuple(model_config['image_size']),
            base_patch_size=tuple(model_config['patch_size']),
            embed_dim=model_config['d_model'][0],
            num_scales=dynamic_chunking_config.get('num_scales', 1),
            boundary_threshold=dynamic_chunking_config.get('boundary_threshold', 0.8),
            max_boundary_ratio=dynamic_chunking_config.get('max_boundary_ratio', 0.2),
            use_minimal_chunking=dynamic_chunking_config.get('use_minimal_chunking', True)
        )
        
        # H-Net backbone
        self.backbone = HNet(
            config=hnet_config,
            stage_idx=0,
            device=device,
            dtype=dtype
        )
        
        # 场景图解码器
        self.scene_graph_decoder = SceneGraphDecoder(
            hidden_dim=model_config['d_model'][0],
            num_object_classes=model_config['num_object_classes'],
            num_predicate_classes=model_config['num_predicate_classes'],
            num_attribute_classes=model_config['num_attribute_classes'],
            max_objects=model_config['max_objects_per_image']
        )
        
        # 初始化权重
        self.apply(self._init_weights)
        
    def _init_weights(self, module):
        """初始化权重"""
        if isinstance(module, nn.Linear):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                torch.nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Conv2d):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                torch.nn.init.zeros_(module.bias)
        elif isinstance(module, nn.LayerNorm):
            torch.nn.init.zeros_(module.bias)
            torch.nn.init.ones_(module.weight)
            
    def allocate_inference_cache(self, batch_size: int, max_seqlen: int, dtype=None):
        """分配推理缓存"""
        return self.backbone.allocate_inference_cache(batch_size, max_seqlen, dtype)
        
    def forward(
        self,
        images: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
        inference_params: Optional[HNetState] = None
    ) -> SceneGraphOutput:
        """前向传播
        
        Args:
            images: (B, C, H, W) 输入图像
            mask: (B, seq_len) 可选的mask
            inference_params: 推理参数
            
        Returns:
            场景图生成结果
        """
        B = images.shape[0]
        
        # 动态图像嵌入，获取分块边界分数
        embedding_output = self.patch_embedding(images)
        if isinstance(embedding_output, tuple):
            patch_embeddings, chunk_scores = embedding_output
        else:
            patch_embeddings = embedding_output
            chunk_scores = None
        
        # 创建mask（如果没有提供）
        if mask is None:
            seq_len = patch_embeddings.shape[1]
            mask = torch.ones(B, seq_len, device=images.device, dtype=torch.bool)
        
        # H-Net处理
        hidden_states, boundary_predictions = self.backbone(
            patch_embeddings,
            mask=mask,
            inference_params=inference_params
        )
        
        # 场景图解码，传递边界信息和分块分数
        scene_graph_outputs = self.scene_graph_decoder(
            hidden_states,
            boundary_info=boundary_predictions,
            chunk_scores=chunk_scores
        )
        
        return SceneGraphOutput(
            object_logits=scene_graph_outputs['object_logits'],
            attribute_logits=scene_graph_outputs['attribute_logits'],
            relationship_logits=scene_graph_outputs['relationship_logits'],
            object_existence=scene_graph_outputs['object_existence'],
            boundary_predictions=boundary_predictions,
            inference_params=inference_params
        )
        
    def step(
        self,
        images: torch.Tensor,
        inference_params: HNetState
    ) -> SceneGraphOutput:
        """单步推理（用于生成）"""
        # 动态图像嵌入
        embedding_output = self.patch_embedding(images)
        if isinstance(embedding_output, tuple):
            patch_embeddings, chunk_scores = embedding_output
        else:
            patch_embeddings = embedding_output
            chunk_scores = None
        
        # H-Net单步处理
        hidden_states, boundary_predictions = self.backbone.step(
            patch_embeddings,
            inference_params
        )
        
        # 场景图解码，传递边界信息和分块分数
        scene_graph_outputs = self.scene_graph_decoder(
            hidden_states,
            boundary_info=boundary_predictions,
            chunk_scores=chunk_scores
        )
        
        return SceneGraphOutput(
            object_logits=scene_graph_outputs['object_logits'],
            attribute_logits=scene_graph_outputs['attribute_logits'],
            relationship_logits=scene_graph_outputs['relationship_logits'],
            object_existence=scene_graph_outputs['object_existence'],
            boundary_predictions=boundary_predictions,
            inference_params=inference_params
        )


def create_model(config: Dict, device=None, dtype=None) -> SceneGraphHNet:
    """创建场景图生成模型"""
    model = SceneGraphHNet(config, device=device, dtype=dtype)
    return model