import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List, Optional
import numpy as np


class FocalLoss(nn.Module):
    """Focal Loss for addressing class imbalance"""
    
    def __init__(self, alpha: float = 1.0, gamma: float = 2.0, reduction: str = 'mean'):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction
        
    def forward(self, inputs: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        ce_loss = F.cross_entropy(inputs, targets, reduction='none')
        pt = torch.exp(-ce_loss)
        focal_loss = self.alpha * (1 - pt) ** self.gamma * ce_loss
        
        if self.reduction == 'mean':
            return focal_loss.mean()
        elif self.reduction == 'sum':
            return focal_loss.sum()
        else:
            return focal_loss


class BalancedBCELoss(nn.Module):
    """Balanced Binary Cross Entropy Loss"""
    
    def __init__(self, pos_weight: Optional[float] = None):
        super().__init__()
        self.pos_weight = pos_weight
        
    def forward(self, inputs: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        if self.pos_weight is not None:
            pos_weight = torch.tensor(self.pos_weight, device=inputs.device)
            return F.binary_cross_entropy_with_logits(
                inputs, targets, pos_weight=pos_weight
            )
        else:
            return F.binary_cross_entropy_with_logits(inputs, targets)


class SceneGraphLoss(nn.Module):
    """场景图生成的综合损失函数"""
    
    def __init__(self, config: Dict):
        super().__init__()
        self.config = config
        loss_config = config['loss']
        
        # 权重
        self.object_detection_weight = loss_config['object_detection_weight']
        self.attribute_weight = loss_config['attribute_weight']
        self.relationship_weight = loss_config['relationship_weight']
        self.boundary_regularization_weight = loss_config['boundary_regularization_weight']
        
        # 损失函数
        self.focal_loss = FocalLoss(
            alpha=loss_config['focal_loss_alpha'],
            gamma=loss_config['focal_loss_gamma']
        )
        
        self.bce_loss = nn.BCEWithLogitsLoss()
        self.mse_loss = nn.MSELoss()
        
        # 类别权重（用于处理类别不平衡）
        self.register_buffer('object_class_weights', torch.ones(config['model']['num_object_classes']))
        self.register_buffer('predicate_class_weights', torch.ones(config['model']['num_predicate_classes']))
        self.register_buffer('attribute_class_weights', torch.ones(config['model']['num_attribute_classes']))
        
    def update_class_weights(self, object_weights: torch.Tensor, 
                           predicate_weights: torch.Tensor,
                           attribute_weights: torch.Tensor):
        """更新类别权重"""
        self.object_class_weights.copy_(object_weights)
        self.predicate_class_weights.copy_(predicate_weights)
        self.attribute_class_weights.copy_(attribute_weights)
        
    def object_detection_loss(self, 
                            object_logits: torch.Tensor,
                            object_existence: torch.Tensor,
                            target_classes: torch.Tensor,
                            target_existence: torch.Tensor) -> torch.Tensor:
        """对象检测损失
        
        Args:
            object_logits: (B, max_objects, num_classes) 对象分类logits
            object_existence: (B, max_objects) 对象存在概率
            target_classes: (B, max_objects) 目标类别
            target_existence: (B, max_objects) 目标存在标签
        """
        B, max_objects, num_classes = object_logits.shape
        
        # 对象存在性损失
        existence_loss = self.bce_loss(object_existence, target_existence.float())
        
        # 对象分类损失（只对存在的对象计算）
        valid_mask = target_existence.bool()
        if valid_mask.sum() > 0:
            valid_logits = object_logits[valid_mask]
            valid_targets = target_classes[valid_mask]
            
            # 使用加权交叉熵
            classification_loss = F.cross_entropy(
                valid_logits, valid_targets,
                weight=self.object_class_weights
            )
        else:
            classification_loss = torch.tensor(0.0, device=object_logits.device)
            
        return existence_loss + classification_loss
        
    def attribute_loss(self,
                      attribute_logits: torch.Tensor,
                      target_attributes: torch.Tensor,
                      target_existence: torch.Tensor) -> torch.Tensor:
        """属性预测损失
        
        Args:
            attribute_logits: (B, max_objects, num_attributes) 属性logits
            target_attributes: (B, max_objects, num_attributes) 目标属性（多标签）
            target_existence: (B, max_objects) 对象存在标签
        """
        # 只对存在的对象计算属性损失
        valid_mask = target_existence.bool()
        if valid_mask.sum() > 0:
            valid_logits = attribute_logits[valid_mask]
            valid_targets = target_attributes[valid_mask]
            
            # 多标签二分类损失
            loss = F.binary_cross_entropy_with_logits(
                valid_logits, valid_targets,
                pos_weight=self.attribute_class_weights
            )
        else:
            loss = torch.tensor(0.0, device=attribute_logits.device)
            
        return loss
        
    def relationship_loss(self,
                         relationship_logits: torch.Tensor,
                         target_relationships: torch.Tensor,
                         target_existence: torch.Tensor) -> torch.Tensor:
        """关系预测损失
        
        Args:
            relationship_logits: (B, max_objects, max_objects, num_predicates) 关系logits
            target_relationships: (B, max_objects, max_objects, num_predicates) 目标关系
            target_existence: (B, max_objects) 对象存在标签
        """
        B, max_objects, _, num_predicates = relationship_logits.shape
        
        # 创建有效对象对的mask
        existence_mask = target_existence.bool()  # (B, max_objects)
        pair_mask = existence_mask.unsqueeze(2) & existence_mask.unsqueeze(1)  # (B, max_objects, max_objects)
        
        # 排除自环（对象与自己的关系）
        diag_mask = ~torch.eye(max_objects, device=relationship_logits.device, dtype=torch.bool)
        pair_mask = pair_mask & diag_mask.unsqueeze(0)
        
        if pair_mask.sum() > 0:
            # 展平有效的对象对
            valid_logits = relationship_logits[pair_mask]  # (num_valid_pairs, num_predicates)
            valid_targets = target_relationships[pair_mask]  # (num_valid_pairs, num_predicates)
            
            # 多标签二分类损失
            loss = F.binary_cross_entropy_with_logits(
                valid_logits, valid_targets,
                pos_weight=self.predicate_class_weights
            )
        else:
            loss = torch.tensor(0.0, device=relationship_logits.device)
            
        return loss
        
    def boundary_regularization_loss(self, boundary_predictions: List) -> torch.Tensor:
        """边界预测正则化损失
        
        鼓励模型学习有意义的分层分块
        """
        if not boundary_predictions:
            return torch.tensor(0.0)
            
        total_loss = 0.0
        for boundary_pred in boundary_predictions:
            if hasattr(boundary_pred, 'boundary_prob'):
                # 鼓励边界概率的多样性（避免所有位置都是边界或都不是边界）
                boundary_prob = boundary_pred.boundary_prob[..., 1]  # 取边界概率
                
                # 计算熵，鼓励适度的边界分布
                prob_mean = boundary_prob.mean()
                entropy_loss = -(prob_mean * torch.log(prob_mean + 1e-8) + 
                               (1 - prob_mean) * torch.log(1 - prob_mean + 1e-8))
                
                # 鼓励边界概率在0.1-0.9之间
                sparsity_loss = F.relu(0.1 - prob_mean) + F.relu(prob_mean - 0.9)
                
                total_loss += entropy_loss + sparsity_loss
                
        return total_loss / len(boundary_predictions) if boundary_predictions else torch.tensor(0.0)
        
    def forward(self, predictions: Dict, targets: Dict) -> Dict[str, torch.Tensor]:
        """计算总损失
        
        Args:
            predictions: 模型预测结果
            targets: 目标标签
            
        Returns:
            损失字典
        """
        losses = {}
        
        # 对象检测损失
        obj_loss = self.object_detection_loss(
            predictions.object_logits,
            predictions.object_existence,
            targets['object_classes'],
            targets['object_existence']
        )
        losses['object_detection'] = obj_loss
        
        # 属性预测损失
        attr_loss = self.attribute_loss(
            predictions.attribute_logits,
            targets['object_attributes'],
            targets['object_existence']
        )
        losses['attribute'] = attr_loss
        
        # 关系预测损失
        rel_loss = self.relationship_loss(
            predictions.relationship_logits,
            targets['relationship_matrix'],
            targets['object_existence']
        )
        losses['relationship'] = rel_loss
        
        # 边界正则化损失
        boundary_loss = self.boundary_regularization_loss(
            predictions.boundary_predictions
        )
        losses['boundary_regularization'] = boundary_loss
        
        # 总损失
        total_loss = (
            self.object_detection_weight * obj_loss +
            self.attribute_weight * attr_loss +
            self.relationship_weight * rel_loss +
            self.boundary_regularization_weight * boundary_loss
        )
        losses['total'] = total_loss
        
        return losses


def compute_class_weights(dataset, config: Dict) -> Dict[str, torch.Tensor]:
    """计算类别权重以处理类别不平衡"""
    from collections import Counter
    
    object_counter = Counter()
    predicate_counter = Counter()
    attribute_counter = Counter()
    
    print("计算类别权重...")
    
    for i in range(len(dataset)):
        sample = dataset[i]
        scene_graph = sample['scene_graph']
        
        # 统计对象类别
        object_classes = scene_graph['object_classes']
        num_objects = scene_graph['num_objects']
        for j in range(num_objects):
            object_counter[object_classes[j].item()] += 1
            
        # 统计属性
        object_attributes = scene_graph['object_attributes']
        for j in range(num_objects):
            for k in range(object_attributes.shape[1]):
                if object_attributes[j, k] > 0:
                    attribute_counter[k] += 1
                    
        # 统计关系
        relationship_matrix = scene_graph['relationship_matrix']
        for j in range(num_objects):
            for k in range(num_objects):
                if j != k:
                    for p in range(relationship_matrix.shape[2]):
                        if relationship_matrix[j, k, p] > 0:
                            predicate_counter[p] += 1
    
    # 计算权重（逆频率）
    num_object_classes = config['model']['num_object_classes']
    num_predicate_classes = config['model']['num_predicate_classes']
    num_attribute_classes = config['model']['num_attribute_classes']
    
    object_weights = torch.ones(num_object_classes)
    predicate_weights = torch.ones(num_predicate_classes)
    attribute_weights = torch.ones(num_attribute_classes)
    
    # 对象权重
    total_objects = sum(object_counter.values())
    for class_idx, count in object_counter.items():
        if count > 0:
            object_weights[class_idx] = total_objects / (num_object_classes * count)
            
    # 谓词权重
    total_predicates = sum(predicate_counter.values())
    for pred_idx, count in predicate_counter.items():
        if count > 0:
            predicate_weights[pred_idx] = total_predicates / (num_predicate_classes * count)
            
    # 属性权重
    total_attributes = sum(attribute_counter.values())
    for attr_idx, count in attribute_counter.items():
        if count > 0:
            attribute_weights[attr_idx] = total_attributes / (num_attribute_classes * count)
    
    return {
        'object_weights': object_weights,
        'predicate_weights': predicate_weights,
        'attribute_weights': attribute_weights
    }