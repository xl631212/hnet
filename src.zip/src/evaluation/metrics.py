import torch
import numpy as np
from typing import Dict, List, Tuple, Optional
from collections import defaultdict
import json
from sklearn.metrics import average_precision_score, precision_recall_curve
import networkx as nx


class SceneGraphMetrics:
    """场景图生成评估指标"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.num_object_classes = config['model']['num_object_classes']
        self.num_predicate_classes = config['model']['num_predicate_classes']
        self.num_attribute_classes = config['model']['num_attribute_classes']
        
        # 评估阈值
        self.object_threshold = config['evaluation']['object_threshold']
        self.attribute_threshold = config['evaluation']['attribute_threshold']
        self.relationship_threshold = config['evaluation']['relationship_threshold']
        
        # IoU阈值用于对象匹配
        self.iou_thresholds = config['evaluation']['iou_thresholds']
        
    def compute_metrics(self, predictions: List[Dict], targets: List[Dict]) -> Dict[str, float]:
        """计算所有评估指标"""
        metrics = {}
        
        # 对象检测指标
        obj_metrics = self._compute_object_detection_metrics(predictions, targets)
        metrics.update(obj_metrics)
        
        # 属性预测指标
        attr_metrics = self._compute_attribute_metrics(predictions, targets)
        metrics.update(attr_metrics)
        
        # 关系预测指标
        rel_metrics = self._compute_relationship_metrics(predictions, targets)
        metrics.update(rel_metrics)
        
        # 场景图整体指标
        sg_metrics = self._compute_scene_graph_metrics(predictions, targets)
        metrics.update(sg_metrics)
        
        # 计算综合指标
        metrics['mean_ap'] = np.mean([
            metrics.get('object_map', 0.0),
            metrics.get('attribute_map', 0.0),
            metrics.get('relationship_map', 0.0)
        ])
        
        return metrics
        
    def _compute_object_detection_metrics(self, predictions: List[Dict], targets: List[Dict]) -> Dict[str, float]:
        """计算对象检测指标"""
        try:
            all_pred_scores = []
            all_pred_labels = []
            all_true_labels = []
            
            total_tp = 0
            total_fp = 0
            total_fn = 0
            
            for pred, target in zip(predictions, targets):
                # 获取预测和目标
                pred_existence = torch.sigmoid(pred['object_existence'])  # (max_objects,)
                pred_logits = pred['object_logits']  # (max_objects, num_classes)
                pred_probs = torch.softmax(pred_logits, dim=-1)
                
                target_existence = target['object_existence']  # (max_objects,)
                target_classes = target['object_classes']  # (max_objects,)
                
                # 找到存在的对象
                pred_mask = pred_existence > self.object_threshold
                target_mask = target_existence > 0.5
                
                # 预测的对象
                pred_indices = torch.where(pred_mask)[0]
                pred_classes = torch.argmax(pred_probs[pred_indices], dim=-1) if len(pred_indices) > 0 else torch.tensor([])
                pred_scores = pred_existence[pred_indices] if len(pred_indices) > 0 else torch.tensor([])
                
                # 真实的对象
                target_indices = torch.where(target_mask)[0]
                true_classes = target_classes[target_indices] if len(target_indices) > 0 else torch.tensor([])
                
                # 计算匹配
                if len(pred_indices) > 0 and len(target_indices) > 0:
                    # 简化版本：基于类别匹配（实际应用中可能需要考虑空间位置）
                    matched_pred = set()
                    matched_target = set()
                    
                    for i, pred_cls in enumerate(pred_classes):
                        for j, true_cls in enumerate(true_classes):
                            if torch.equal(pred_cls, true_cls) and j not in matched_target:
                                matched_pred.add(i)
                                matched_target.add(j)
                                break
                                
                    tp = len(matched_pred)
                    fp = len(pred_indices) - tp
                    fn = len(target_indices) - len(matched_target)
                else:
                    tp = 0
                    fp = len(pred_indices)
                    fn = len(target_indices)
                    
                total_tp += tp
                total_fp += fp
                total_fn += fn
                
                # 收集用于AP计算的数据
                for i, pred_cls in enumerate(pred_classes):
                    score = pred_scores[i]
                    if score.numel() > 1:
                        all_pred_scores.append(score.max().item())
                    else:
                        all_pred_scores.append(score.item())
                    if pred_cls.numel() > 1:
                        all_pred_labels.append(pred_cls.argmax().item())
                    else:
                        all_pred_labels.append(pred_cls.item())

                    is_match = i in matched_pred
                    all_true_labels.append(is_match)
                    
            # 计算精确率、召回率、F1
            precision = total_tp / (total_tp + total_fp) if (total_tp + total_fp) > 0 else 0.0
            recall = total_tp / (total_tp + total_fn) if (total_tp + total_fn) > 0 else 0.0
            f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
            
            # 计算mAP
            object_map = 0.0
            if len(all_pred_scores) > 0:
                y_true = np.array(all_true_labels)
                y_scores = np.array(all_pred_scores)
                object_map = average_precision_score(y_true, y_scores)
            
                
            return {
                'object_precision': precision,
                'object_recall': recall,
                'object_f1': f1,
                'object_map': object_map
            }
        except Exception as e:
            print(f"Error in _compute_object_detection_metrics: {e}. Returning 0 values.")
            return {
                'object_precision': 0.0,
                'object_recall': 0.0,
                'object_f1': 0.0,
                'object_map': 0.0
            }
        
    def _compute_attribute_metrics(self, predictions: List[Dict], targets: List[Dict]) -> Dict[str, float]:
        """计算属性预测指标"""
        try:
            all_pred_probs = []
            all_true_labels = []
            
            for pred, target in zip(predictions, targets):
                pred_logits = pred['attribute_logits']  # (max_objects, num_attributes)
                pred_probs = torch.sigmoid(pred_logits)
                
                target_attributes = target['object_attributes']  # (max_objects, num_attributes)
                target_existence = target['object_existence']  # (max_objects,)
                
                # 只考虑存在的对象
                valid_mask = target_existence > 0.5
                if valid_mask.sum() > 0:
                    valid_pred_probs = pred_probs[valid_mask]
                    valid_target_attrs = target_attributes[valid_mask]
                    
                    all_pred_probs.append(valid_pred_probs.flatten())
                    all_true_labels.append(valid_target_attrs.flatten())
                    
            if len(all_pred_probs) > 0:
                all_pred_probs = torch.cat(all_pred_probs).cpu().numpy()
                all_true_labels = torch.cat(all_true_labels).cpu().numpy()
                
                # 计算mAP
                attribute_map = average_precision_score(all_true_labels, all_pred_probs)
                
                # 计算精确率、召回率、F1
                pred_binary = (all_pred_probs > self.attribute_threshold).astype(int)
                
                tp = np.sum((pred_binary == 1) & (all_true_labels == 1))
                fp = np.sum((pred_binary == 1) & (all_true_labels == 0))
                fn = np.sum((pred_binary == 0) & (all_true_labels == 1))
                
                precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
                recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
                f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
            else:
                attribute_map = 0.0
                precision = 0.0
                recall = 0.0
                f1 = 0.0
                
            return {
                'attribute_precision': precision,
                'attribute_recall': recall,
                'attribute_f1': f1,
                'attribute_map': attribute_map
            }
        except Exception as e:
            print(f"Error in _compute_attribute_metrics: {e}. Returning 0 values.")
            return {
                'attribute_precision': 0.0,
                'attribute_recall': 0.0,
                'attribute_f1': 0.0,
                'attribute_map': 0.0
            }
        
    def _compute_relationship_metrics(self, predictions: List[Dict], targets: List[Dict]) -> Dict[str, float]:
        """计算关系预测指标"""
        try:
            all_pred_probs = []
            all_true_labels = []
            
            for pred, target in zip(predictions, targets):
                pred_logits = pred['relationship_logits']  # (max_objects, max_objects, num_predicates)
                pred_probs = torch.sigmoid(pred_logits)
                
                target_relationships = target['relationship_matrix']  # (max_objects, max_objects, num_predicates)
                target_existence = target['object_existence']  # (max_objects,)
                
                num_obj = target_existence.shape[0]

                # Slice predictions to match ground truth number of objects
                pred_probs_sliced = pred_probs[:num_obj, :num_obj, :]

                # Create a mask for existing object pairs, excluding self-loops
                valid_mask = target_existence > 0.5
                pair_mask = valid_mask.unsqueeze(1) & valid_mask.unsqueeze(0)
                diag_mask = ~torch.eye(num_obj, dtype=torch.bool, device=pred_logits.device)
                final_mask = pair_mask & diag_mask

                if final_mask.sum() > 0:
                    valid_pred_probs = pred_probs_sliced[final_mask]
                    valid_target_rels = target_relationships[:num_obj, :num_obj][final_mask]
                    
                    all_pred_probs.append(valid_pred_probs.flatten())
                    all_true_labels.append(valid_target_rels.flatten())
                    
            if len(all_pred_probs) > 0:
                all_pred_probs = torch.cat(all_pred_probs).cpu().numpy()
                all_true_labels = torch.cat(all_true_labels).cpu().numpy()
                
                # 计算mAP
                relationship_map = average_precision_score(all_true_labels, all_pred_probs)
                
                # 计算精确率、召回率、F1
                pred_binary = (all_pred_probs > self.relationship_threshold).astype(int)
                
                tp = np.sum((pred_binary == 1) & (all_true_labels == 1))
                fp = np.sum((pred_binary == 1) & (all_true_labels == 0))
                fn = np.sum((pred_binary == 0) & (all_true_labels == 1))
                
                precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
                recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
                f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
            else:
                relationship_map = 0.0
                precision = 0.0
                recall = 0.0
                f1 = 0.0
                
            return {
                'relationship_precision': precision,
                'relationship_recall': recall,
                'relationship_f1': f1,
                'relationship_map': relationship_map
            }
        except Exception as e:
            print(f"Error in _compute_relationship_metrics: {e}. Returning 0 values.")
            return {
                'relationship_precision': 0.0,
                'relationship_recall': 0.0,
                'relationship_f1': 0.0,
                'relationship_map': 0.0
            }
        
    def _compute_scene_graph_metrics(self, predictions: List[Dict], targets: List[Dict]) -> Dict[str, float]:
        """计算场景图整体指标"""
        try:
            total_graph_accuracy = 0.0
            total_triplet_recall = 0.0
            num_samples = len(predictions)
            
            for pred, target in zip(predictions, targets):
                # 解析预测的场景图
                pred_sg = self._parse_scene_graph(pred)
                target_sg = self._parse_scene_graph_from_target(target)
                
                # 计算图级别的准确率
                graph_acc = self._compute_graph_accuracy(pred_sg, target_sg)
                total_graph_accuracy += graph_acc
                
                # 计算三元组召回率
                triplet_recall = self._compute_triplet_recall(pred_sg, target_sg)
                total_triplet_recall += triplet_recall
                
            return {
                'scene_graph_accuracy': total_graph_accuracy / num_samples if num_samples > 0 else 0.0,
                'triplet_recall': total_triplet_recall / num_samples if num_samples > 0 else 0.0
            }
        except Exception as e:
            print(f"Error in _compute_scene_graph_metrics: {e}. Returning 0 values.")
            return {
                'scene_graph_accuracy': 0.0,
                'triplet_recall': 0.0
            }
        
    def _parse_scene_graph(self, pred: Dict) -> Dict:
        """从预测结果解析场景图"""
        try:
            # 获取存在的对象
            object_existence = torch.sigmoid(pred['object_existence'])
            object_logits = pred['object_logits']
            attribute_logits = pred['attribute_logits']
            relationship_logits = pred['relationship_logits']
            
            # 解析对象
            object_mask = object_existence > self.object_threshold
            object_indices = torch.where(object_mask)[0]
            
            objects = []
            for idx in object_indices:
                try:
                    obj_class = torch.argmax(object_logits[idx]).item()
                    obj_attrs = torch.where(torch.sigmoid(attribute_logits[idx]) > self.attribute_threshold)[0].tolist()
                    objects.append({
                        'id': idx.item(),
                        'class': obj_class,
                        'attributes': obj_attrs
                    })
                except Exception as e:
                    # 跳过有问题的对象
                    continue
                
            # 解析关系
            relationships = []
            for i, idx_i in enumerate(object_indices):
                for j, idx_j in enumerate(object_indices):
                    if i != j:
                        try:
                            rel_probs = torch.sigmoid(relationship_logits[idx_i, idx_j])
                            rel_indices = torch.where(rel_probs > self.relationship_threshold)[0]
                            
                            for rel_idx in rel_indices:
                                relationships.append({
                                    'subject': idx_i.item(),
                                    'predicate': rel_idx.item(),
                                    'object': idx_j.item()
                                })
                        except Exception as e:
                            # 跳过有问题的关系
                            continue
                            
            return {
                'objects': objects,
                'relationships': relationships
            }
        except Exception as e:
            # 返回空的场景图
            return {
                'objects': [],
                'relationships': []
            }
        
    def _parse_scene_graph_from_target(self, target: Dict) -> Dict:
        """从目标标签解析场景图"""
        object_existence = target['object_existence']
        object_classes = target['object_classes']
        object_attributes = target['object_attributes']
        relationship_matrix = target['relationship_matrix']
        
        # 解析对象
        object_mask = object_existence > 0.5
        object_indices = torch.where(object_mask)[0]
        
        objects = []
        for idx in object_indices:
            obj_class = object_classes[idx].item()
            obj_attrs = torch.where(object_attributes[idx] > 0.5)[0].tolist()
            objects.append({
                'id': idx.item(),
                'class': obj_class,
                'attributes': obj_attrs
            })
            
        # 解析关系
        relationships = []
        for i, idx_i in enumerate(object_indices):
            for j, idx_j in enumerate(object_indices):
                if i != j:
                    rel_indices = torch.where(relationship_matrix[idx_i, idx_j] > 0.5)[0]
                    
                    for rel_idx in rel_indices:
                        relationships.append({
                            'subject': idx_i.item(),
                            'predicate': rel_idx.item(),
                            'object': idx_j.item()
                        })
                        
        return {
            'objects': objects,
            'relationships': relationships
        }
        
    def _compute_graph_accuracy(self, pred_sg: Dict, target_sg: Dict) -> float:
        """计算图级别的准确率"""
        # 简化版本：比较对象和关系的数量
        pred_obj_count = len(pred_sg['objects'])
        target_obj_count = len(target_sg['objects'])
        
        pred_rel_count = len(pred_sg['relationships'])
        target_rel_count = len(target_sg['relationships'])
        
        # 计算相对误差
        obj_error = abs(pred_obj_count - target_obj_count) / max(target_obj_count, 1)
        rel_error = abs(pred_rel_count - target_rel_count) / max(target_rel_count, 1)
        
        # 转换为准确率（误差越小，准确率越高）
        accuracy = 1.0 - (obj_error + rel_error) / 2.0
        result = max(0.0, accuracy)
        
        # 确保返回Python标量而不是tensor
        if isinstance(result, torch.Tensor):
            result = result.item()
        return float(result)
        
    def _compute_triplet_recall(self, pred_sg: Dict, target_sg: Dict) -> float:
        """计算三元组召回率"""
        if len(target_sg['relationships']) == 0:
            return 1.0 if len(pred_sg['relationships']) == 0 else 0.0
            
        # 创建三元组集合
        pred_triplets = set()
        for rel in pred_sg['relationships']:
            # 找到对应的对象类别
            subj_class = None
            obj_class = None
            
            for obj in pred_sg['objects']:
                if obj['id'] == rel['subject']:
                    subj_class = obj['class']
                if obj['id'] == rel['object']:
                    obj_class = obj['class']
                    
            if subj_class is not None and obj_class is not None:
                triplet = (subj_class, rel['predicate'], obj_class)
                pred_triplets.add(triplet)
                
        target_triplets = set()
        for rel in target_sg['relationships']:
            # 找到对应的对象类别
            subj_class = None
            obj_class = None
            
            for obj in target_sg['objects']:
                if obj['id'] == rel['subject']:
                    subj_class = obj['class']
                if obj['id'] == rel['object']:
                    obj_class = obj['class']
                    
            if subj_class is not None and obj_class is not None:
                triplet = (subj_class, rel['predicate'], obj_class)
                target_triplets.add(triplet)
                
        # 计算召回率
        if len(target_triplets) == 0:
            return 1.0
            
        matched = len(pred_triplets & target_triplets)
        recall = matched / len(target_triplets)
        
        # 确保返回Python标量而不是tensor
        if isinstance(recall, torch.Tensor):
            recall = recall.item()
        return float(recall)
        
    def format_results(self, metrics: Dict[str, float]) -> str:
        """格式化评估结果"""
        result_str = "\n=== 场景图生成评估结果 ===\n"
        
        # 对象检测指标
        result_str += "\n对象检测:\n"
        result_str += f"  精确率: {metrics.get('object_precision', 0.0):.4f}\n"
        result_str += f"  召回率: {metrics.get('object_recall', 0.0):.4f}\n"
        result_str += f"  F1分数: {metrics.get('object_f1', 0.0):.4f}\n"
        result_str += f"  mAP: {metrics.get('object_map', 0.0):.4f}\n"
        
        # 属性预测指标
        result_str += "\n属性预测:\n"
        result_str += f"  精确率: {metrics.get('attribute_precision', 0.0):.4f}\n"
        result_str += f"  召回率: {metrics.get('attribute_recall', 0.0):.4f}\n"
        result_str += f"  F1分数: {metrics.get('attribute_f1', 0.0):.4f}\n"
        result_str += f"  mAP: {metrics.get('attribute_map', 0.0):.4f}\n"
        
        # 关系预测指标
        result_str += "\n关系预测:\n"
        result_str += f"  精确率: {metrics.get('relationship_precision', 0.0):.4f}\n"
        result_str += f"  召回率: {metrics.get('relationship_recall', 0.0):.4f}\n"
        result_str += f"  F1分数: {metrics.get('relationship_f1', 0.0):.4f}\n"
        result_str += f"  mAP: {metrics.get('relationship_map', 0.0):.4f}\n"
        
        # 场景图整体指标
        result_str += "\n场景图整体:\n"
        result_str += f"  图准确率: {metrics.get('scene_graph_accuracy', 0.0):.4f}\n"
        result_str += f"  三元组召回率: {metrics.get('triplet_recall', 0.0):.4f}\n"
        
        # 综合指标
        result_str += "\n综合指标:\n"
        result_str += f"  平均mAP: {metrics.get('mean_ap', 0.0):.4f}\n"
        
        return result_str